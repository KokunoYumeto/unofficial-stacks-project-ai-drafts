#!/usr/bin/env python3
"""Fail-closed validator for the Mathematics Commons Stacks sidecar.

This module deliberately separates syntactic JSON Schema validation from the
cross-file and Git-aware invariants that JSON Schema cannot express.  It has no
network dependency and may be run from any working directory.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Any, Iterable, Mapping, Sequence

from jsonschema import Draft202012Validator, FormatChecker


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
FORMAT_CHECKER = FormatChecker()
SHA256_RE = re.compile(r"^[0-9A-F]{64}$")
EVENT_ID_RE = re.compile(r"^lease-event-([0-9]{6})$")


class RepositoryValidationError(RuntimeError):
    """A repository invariant failed."""


@FORMAT_CHECKER.checks("date-time")
def _is_rfc3339_datetime(value: object) -> bool:
    """Validate an offset-bearing RFC 3339 timestamp without optional extras."""

    if not isinstance(value, str):
        return True
    if not re.fullmatch(
        r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}"
        r"(?:\.[0-9]+)?(?:Z|[+-][0-9]{2}:[0-9]{2})",
        value,
    ):
        return False
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    return True


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise RepositoryValidationError(message)


def _load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise RepositoryValidationError(f"missing JSON file: {path}") from exc
    except json.JSONDecodeError as exc:
        raise RepositoryValidationError(
            f"invalid JSON in {path}: line {exc.lineno}, column {exc.colno}: {exc.msg}"
        ) from exc


def _format_json_path(parts: Iterable[object]) -> str:
    rendered = "$"
    for part in parts:
        if isinstance(part, int):
            rendered += f"[{part}]"
        else:
            rendered += f".{part}"
    return rendered


def _validate_with_schema(instance: Any, schema: Any, label: str) -> None:
    try:
        Draft202012Validator.check_schema(schema)
    except Exception as exc:  # jsonschema exposes several schema error classes
        raise RepositoryValidationError(f"invalid validator schema for {label}: {exc}") from exc
    validator = Draft202012Validator(schema, format_checker=FORMAT_CHECKER)
    errors = sorted(
        validator.iter_errors(instance),
        key=lambda item: tuple(str(part) for part in item.absolute_path),
    )
    if errors:
        details = "; ".join(
            f"{_format_json_path(error.absolute_path)}: {error.message}"
            for error in errors
        )
        raise RepositoryValidationError(f"schema validation failed for {label}: {details}")


def _schema_validate_file(root: Path, data_rel: str, schema_rel: str) -> Any:
    data = _load_json(root / data_rel)
    schema = _load_json(root / schema_rel)
    _validate_with_schema(data, schema, data_rel)
    return data


def _canonical_repo_file(
    root: Path,
    raw_path: object,
    *,
    label: str,
    within: str | None = None,
) -> tuple[str, Path]:
    _require(isinstance(raw_path, str) and raw_path != "", f"{label}: path must be a nonempty string")
    value = raw_path
    _require("\\" not in value, f"{label}: backslashes are not canonical: {value!r}")
    _require("\x00" not in value and ":" not in value, f"{label}: unsafe path: {value!r}")
    pure = PurePosixPath(value)
    _require(not pure.is_absolute(), f"{label}: absolute path is forbidden: {value!r}")
    _require(
        all(part not in ("", ".", "..") for part in pure.parts),
        f"{label}: dot or empty path component is forbidden: {value!r}",
    )
    _require(pure.as_posix() == value, f"{label}: noncanonical path spelling: {value!r}")
    if within is not None:
        prefix = PurePosixPath(within)
        _require(
            pure == prefix or prefix in pure.parents,
            f"{label}: path escapes leased root {within!r}: {value!r}",
        )

    root_resolved = root.resolve(strict=True)
    candidate = root.joinpath(*pure.parts)
    try:
        resolved = candidate.resolve(strict=True)
    except FileNotFoundError as exc:
        raise RepositoryValidationError(f"{label}: referenced file does not exist: {value}") from exc
    try:
        resolved.relative_to(root_resolved)
    except ValueError as exc:
        raise RepositoryValidationError(f"{label}: resolved path escapes repository: {value}") from exc
    current = root_resolved
    for part in pure.parts:
        current = current / part
        _require(not current.is_symlink(), f"{label}: symlink path component is forbidden: {value}")
    _require(resolved.is_file(), f"{label}: referenced path is not a regular file: {value}")
    return value, resolved


def _git_output(root: Path, arguments: Sequence[str]) -> bytes:
    process = subprocess.run(
        ["git", "-C", str(root), *arguments],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if process.returncode != 0:
        stderr = process.stderr.decode("utf-8", errors="replace").strip()
        raise RepositoryValidationError(f"git {' '.join(arguments)} failed: {stderr}")
    return process.stdout


def git_tracked_files(root: Path) -> set[str]:
    output = _git_output(root, ["ls-files", "-z"])
    return {
        item.decode("utf-8")
        for item in output.split(b"\0")
        if item
    }


def _require_tracked(path: str, tracked_files: set[str], label: str) -> None:
    _require(path in tracked_files, f"{label}: referenced file is not Git tracked: {path}")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def _parse_timestamp(value: str, label: str) -> datetime:
    _require(_is_rfc3339_datetime(value), f"{label}: invalid RFC 3339 date-time: {value!r}")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    _require(parsed.utcoffset() is not None, f"{label}: timestamp must have a UTC offset")
    return parsed


def _require_utc_z(value: str, label: str) -> datetime:
    parsed = _parse_timestamp(value, label)
    _require(value.endswith("Z"), f"{label}: *_utc timestamp must use canonical Z notation")
    return parsed


def _validate_upstream_semantics(lock: Mapping[str, Any]) -> None:
    _require(
        lock["literal_fork_commit_at_observation"] == lock["commit"],
        "upstream lock: literal fork commit does not equal pinned upstream commit",
    )
    _require(
        f"/{lock['commit']}/COPYING" in lock["license"]["raw_url"],
        "upstream lock: licence URL is not bound to the pinned commit",
    )
    _require(lock["ref"].endswith("/" + lock["default_branch"]), "upstream lock: ref/default branch mismatch")
    _require(
        lock["literal_fork_ref"].endswith("/" + lock["default_branch"]),
        "upstream lock: literal fork ref/default branch mismatch",
    )
    _require_utc_z(lock["observed_at_utc"], "upstream lock observed_at_utc")


def _immutable_lease_fields(event: Mapping[str, Any]) -> dict[str, Any]:
    keys = (
        "lease_id",
        "namespace",
        "candidate_path",
        "writer_task",
        "upstream_commit",
        "upstream_tree",
        "issued_at_utc",
        "writer_contract",
    )
    return {key: event[key] for key in keys}


def _validate_lease_lifecycle(
    root: Path,
    registry: Mapping[str, Any],
    lock: Mapping[str, Any],
    tracked_files: set[str],
) -> tuple[dict[str, Mapping[str, Any]], dict[str, Mapping[str, Any]]]:
    histories: dict[str, list[Mapping[str, Any]]] = {}
    seen_event_ids: set[str] = set()
    issued: dict[str, Mapping[str, Any]] = {}

    for position, event in enumerate(registry["events"], start=1):
        event_id = event["event_id"]
        match = EVENT_ID_RE.fullmatch(event_id)
        _require(match is not None, f"lease registry: malformed event id {event_id!r}")
        _require(int(match.group(1)) == position, f"lease registry: event ids must be contiguous in array order; expected {position:06d}")
        _require(event_id not in seen_event_ids, f"lease registry: duplicate event id {event_id}")
        seen_event_ids.add(event_id)

        namespace, _ = _canonical_repo_file(
            root,
            event["writer_contract"],
            label=f"{event_id}.writer_contract",
        )
        _require_tracked(namespace, tracked_files, f"{event_id}.writer_contract")
        _require(
            event["candidate_path"] == "candidates/" + event["namespace"],
            f"lease registry: {event_id} candidate_path is not the canonical namespace projection",
        )
        _require(event["upstream_commit"] == lock["commit"], f"lease registry: {event_id} upstream commit differs from lock")
        _require(event["upstream_tree"] == lock["tree"], f"lease registry: {event_id} upstream tree differs from lock")
        issued_time = _require_utc_z(event["issued_at_utc"], f"{event_id}.issued_at_utc")

        lease_id = event["lease_id"]
        history = histories.setdefault(lease_id, [])
        if event["event"] == "issued":
            _require(not history, f"lease registry: lease {lease_id} was issued more than once")
            _require(event["state"] == "active", f"lease registry: issued lease {lease_id} must be active")
            issued[lease_id] = event
        else:
            _require(history, f"lease registry: transition {event_id} has no prior issuance")
            previous = history[-1]
            _require(previous["state"] == "active", f"lease registry: terminal lease {lease_id} cannot transition again")
            _require(
                event.get("supersedes_event_id") == previous["event_id"],
                f"lease registry: {event_id} must supersede the immediately prior event for {lease_id}",
            )
            _require(
                _immutable_lease_fields(event) == _immutable_lease_fields(issued[lease_id]),
                f"lease registry: immutable lease fields changed in {event_id}",
            )
            event_time = _require_utc_z(event["event_at_utc"], f"{event_id}.event_at_utc")
            _require(event_time >= issued_time, f"lease registry: {event_id} predates lease issuance")
            expected_state = event["event"]
            _require(event["state"] == expected_state, f"lease registry: {event_id} event/state mismatch")
        history.append(event)

    effective = {lease_id: history[-1] for lease_id, history in histories.items()}
    active = {lease_id: event for lease_id, event in effective.items() if event["state"] == "active"}
    active_events = list(active.values())
    for index, left in enumerate(active_events):
        left_namespace = PurePosixPath(left["namespace"])
        left_path = PurePosixPath(left["candidate_path"])
        for right in active_events[index + 1 :]:
            right_namespace = PurePosixPath(right["namespace"])
            right_path = PurePosixPath(right["candidate_path"])
            namespace_overlap = (
                left_namespace == right_namespace
                or left_namespace in right_namespace.parents
                or right_namespace in left_namespace.parents
            )
            path_overlap = left_path == right_path or left_path in right_path.parents or right_path in left_path.parents
            _require(
                not namespace_overlap and not path_overlap,
                f"lease registry: active ancestor-chain collision between {left['lease_id']} and {right['lease_id']}",
            )
    return issued, active


def _validate_pointers(
    root: Path,
    issued: Mapping[str, Mapping[str, Any]],
    active: Mapping[str, Mapping[str, Any]],
    tracked_files: set[str],
) -> dict[str, Mapping[str, Any]]:
    pointer_schema = _load_json(root / "schemas/candidate-lease-pointer.schema.json")
    pointers: dict[str, Mapping[str, Any]] = {}
    for pointer_path in sorted((root / "candidates").rglob("LEASE.json")):
        relative = pointer_path.relative_to(root).as_posix()
        _require_tracked(relative, tracked_files, relative)
        pointer = _load_json(pointer_path)
        _validate_with_schema(pointer, pointer_schema, relative)
        lease_id = pointer["lease_id"]
        _require(lease_id in issued, f"{relative}: pointer references an unknown lease {lease_id}")
        _require(lease_id not in pointers, f"candidate pointers: duplicate pointer for lease {lease_id}")
        issuance = issued[lease_id]
        expected = {
            "lease_id": issuance["lease_id"],
            "namespace": issuance["namespace"],
            "candidate_path": issuance["candidate_path"],
            "writer_task": issuance["writer_task"],
            "upstream_commit": issuance["upstream_commit"],
            "upstream_tree": issuance["upstream_tree"],
            "writer_contract": issuance["writer_contract"],
        }
        for key, value in expected.items():
            _require(pointer[key] == value, f"{relative}: pointer field {key} differs from issuance")
        _require(
            relative == issuance["candidate_path"] + "/LEASE.json",
            f"{relative}: pointer is outside its canonical candidate path",
        )
        pointers[lease_id] = pointer

    missing = sorted(set(active) - set(pointers))
    _require(not missing, f"candidate pointers: active leases have no pointer: {missing}")

    candidate_root = root / "candidates" / "commons" / "stacks"
    known_roots = [PurePosixPath(event["candidate_path"]) for event in issued.values()]
    if candidate_root.exists():
        for file_path in candidate_root.rglob("*"):
            if not file_path.is_file() and not file_path.is_symlink():
                continue
            relative = PurePosixPath(file_path.relative_to(root).as_posix())
            _require(
                any(relative == base or base in relative.parents for base in known_roots),
                f"unleased file below candidate namespace root: {relative.as_posix()}",
            )
    return pointers


def _manifest_evidence(manifest: Mapping[str, Any]) -> list[tuple[str, Mapping[str, Any]]]:
    evidence: list[tuple[str, Mapping[str, Any]]] = []
    for index, item in enumerate(manifest["source_authorities"]):
        evidence.append((f"source_authorities[{index}]", item))
    for field in (
        "stable_unit_manifest",
        "source_map",
        "decision_ledger",
        "rejection_ledger",
        "formula_diagram_inventory",
    ):
        evidence.append((field, manifest[field]))
    for index, item in enumerate(manifest["builds"]):
        evidence.append((f"builds[{index}]", item))
    return evidence


def _validate_candidate_manifests(
    root: Path,
    issued: Mapping[str, Mapping[str, Any]],
    lock: Mapping[str, Any],
    tracked_files: set[str],
) -> int:
    schema = _load_json(root / "schemas/candidate-manifest.schema.json")
    manifest_paths = sorted((root / "candidates").rglob("candidate.manifest.json"))
    for manifest_path in manifest_paths:
        relative_manifest = manifest_path.relative_to(root).as_posix()
        _require_tracked(relative_manifest, tracked_files, relative_manifest)
        manifest = _load_json(manifest_path)
        _validate_with_schema(manifest, schema, relative_manifest)
        lease_id = manifest["lease_id"]
        _require(lease_id in issued, f"{relative_manifest}: unknown lease {lease_id}")
        lease = issued[lease_id]
        candidate_path = lease["candidate_path"]
        _require(
            relative_manifest == candidate_path + "/candidate.manifest.json",
            f"{relative_manifest}: manifest is not at the leased candidate root",
        )
        for field in ("namespace", "writer_task"):
            _require(manifest[field] == lease[field], f"{relative_manifest}: {field} differs from lease")
        _require(manifest["upstream"]["commit"] == lock["commit"], f"{relative_manifest}: upstream commit differs from lock")
        _require(manifest["upstream"]["tree"] == lock["tree"], f"{relative_manifest}: upstream tree differs from lock")
        _require(
            manifest["source_closure"]["expected_units"] == manifest["source_closure"]["manifested_units"],
            f"{relative_manifest}: source closure counts differ",
        )
        _require(
            len(manifest["stable_ids"]) == manifest["source_closure"]["manifested_units"],
            f"{relative_manifest}: stable-id count differs from manifested unit count",
        )
        _require_utc_z(manifest["generated_at_utc"], f"{relative_manifest}.generated_at_utc")

        inventory: dict[str, str] = {}
        for index, item in enumerate(manifest["file_inventory"]):
            label = f"{relative_manifest}.file_inventory[{index}]"
            path_value, physical = _canonical_repo_file(
                root,
                item["path"],
                label=label,
                within=candidate_path,
            )
            _require(path_value not in inventory, f"{label}: duplicate inventory path {path_value}")
            _require_tracked(path_value, tracked_files, label)
            _require(SHA256_RE.fullmatch(item["sha256"]) is not None, f"{label}: SHA-256 must be uppercase hexadecimal")
            actual_hash = _sha256(physical)
            _require(actual_hash == item["sha256"], f"{label}: SHA-256 mismatch for {path_value}; actual {actual_hash}")
            inventory[path_value] = item["sha256"]

        for field, item in _manifest_evidence(manifest):
            label = f"{relative_manifest}.{field}"
            path_value, physical = _canonical_repo_file(
                root,
                item["path"],
                label=label,
                within=candidate_path,
            )
            _require_tracked(path_value, tracked_files, label)
            _require(path_value in inventory, f"{label}: evidence file is absent from file_inventory: {path_value}")
            actual_hash = _sha256(physical)
            _require(actual_hash == item["sha256"], f"{label}: SHA-256 mismatch for {path_value}; actual {actual_hash}")
            _require(inventory[path_value] == item["sha256"], f"{label}: evidence and inventory hashes disagree")

        candidate_root = root.joinpath(*PurePosixPath(candidate_path).parts)
        actual_files: set[str] = set()
        excluded = {
            candidate_path + "/LEASE.json",
            candidate_path + "/candidate.manifest.json",
        }
        for physical in candidate_root.rglob("*"):
            if not physical.is_file() and not physical.is_symlink():
                continue
            relative = physical.relative_to(root).as_posix()
            if relative not in excluded:
                actual_files.add(relative)
        inventoried = set(inventory)
        _require(
            actual_files == inventoried,
            f"{relative_manifest}: file_inventory is not complete; "
            f"missing={sorted(actual_files - inventoried)}, extra={sorted(inventoried - actual_files)}",
        )
    return len(manifest_paths)


def _unique_field(entries: Sequence[Mapping[str, Any]], field: str, label: str) -> None:
    values = [entry[field] for entry in entries]
    _require(len(values) == len(set(values)), f"{label}: duplicate {field}")


def _validate_admission_registries(
    root: Path,
    overlays: Mapping[str, Any],
    locales: Mapping[str, Any],
    releases: Mapping[str, Any],
    lock: Mapping[str, Any],
    tracked_files: set[str],
) -> None:
    overlay_entries = overlays["registered_entries"]
    _unique_field(overlay_entries, "id", "overlay registry")
    _unique_field(overlay_entries, "namespace", "overlay registry")
    for index, entry in enumerate(overlay_entries):
        _require(entry["source_commit"] == lock["commit"], f"overlay[{index}]: source commit differs from lock")
        _require(entry["source_tree"] == lock["tree"], f"overlay[{index}]: source tree differs from lock")
        _require_utc_z(entry["admitted_at_utc"], f"overlay[{index}].admitted_at_utc")
        review_path, _ = _canonical_repo_file(root, entry["review_receipt"], label=f"overlay[{index}].review_receipt")
        _require_tracked(review_path, tracked_files, f"overlay[{index}].review_receipt")

    release_entries = releases["releases"]
    _unique_field(release_entries, "id", "release registry")
    release_ids = {entry["id"] for entry in release_entries}
    for index, entry in enumerate(release_entries):
        _require(entry["upstream_commit"] == lock["commit"], f"release[{index}]: upstream commit differs from lock")

    locale_entries = locales["admitted_locales"]
    _unique_field(locale_entries, "id", "locale registry")
    _unique_field(locale_entries, "locale", "locale registry")
    for index, entry in enumerate(locale_entries):
        _require(entry["source_release_id"] in release_ids, f"locale[{index}]: unknown source release")
        manifest_path, physical = _canonical_repo_file(root, entry["manifest_path"], label=f"locale[{index}].manifest_path")
        _require_tracked(manifest_path, tracked_files, f"locale[{index}].manifest_path")
        _require(_sha256(physical) == entry["manifest_sha256"], f"locale[{index}]: manifest SHA-256 mismatch")
        review_path, _ = _canonical_repo_file(root, entry["review_receipt"], label=f"locale[{index}].review_receipt")
        _require_tracked(review_path, tracked_files, f"locale[{index}].review_receipt")
        _require_utc_z(entry["admitted_at_utc"], f"locale[{index}].admitted_at_utc")
    _require_utc_z(locales["updated_at_utc"], "locale registry updated_at_utc")
    _require_utc_z(releases["updated_at_utc"], "release registry updated_at_utc")


def compare_append_only_document(
    old: Mapping[str, Any],
    new: Mapping[str, Any],
    *,
    label: str,
    list_key: str,
    mutable_on_append: frozenset[str] = frozenset(),
) -> None:
    """Require an earlier registry list to remain an exact prefix.

    A newly introduced local ``$schema`` pointer is the only migration metadata
    allowed without a list append.  Timestamp fields in ``mutable_on_append``
    may change only when at least one entry is appended.
    """

    _require(list_key in old and list_key in new, f"{label}: missing append-only list {list_key}")
    old_entries = old[list_key]
    new_entries = new[list_key]
    _require(isinstance(old_entries, list) and isinstance(new_entries, list), f"{label}: {list_key} must be arrays")
    _require(len(new_entries) >= len(old_entries), f"{label}: append-only list was truncated")
    _require(new_entries[: len(old_entries)] == old_entries, f"{label}: prior entries were edited or reordered")
    appended = len(new_entries) > len(old_entries)

    old_meta = copy.deepcopy(dict(old))
    new_meta = copy.deepcopy(dict(new))
    old_meta.pop(list_key)
    new_meta.pop(list_key)
    if "$schema" not in old_meta and "$schema" in new_meta:
        new_meta.pop("$schema")
    if appended:
        for key in mutable_on_append:
            old_meta.pop(key, None)
            new_meta.pop(key, None)
    _require(old_meta == new_meta, f"{label}: non-append registry metadata changed")


def _json_at_git_ref(root: Path, ref: str, relative: str) -> Mapping[str, Any]:
    output = _git_output(root, ["show", f"{ref}:{relative}"])
    try:
        value = json.loads(output.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RepositoryValidationError(f"{relative} at base ref {ref!r} is not valid UTF-8 JSON") from exc
    _require(isinstance(value, dict), f"{relative} at base ref {ref!r} is not an object")
    return value


def _validate_append_only_against_base(root: Path, base_ref: str) -> None:
    specifications = (
        ("registry/leases.json", "events", frozenset()),
        ("registry/overlays.json", "registered_entries", frozenset()),
        ("registry/locales.json", "admitted_locales", frozenset({"updated_at_utc"})),
        ("registry/releases.json", "releases", frozenset({"updated_at_utc"})),
    )
    for relative, list_key, mutable in specifications:
        old = _json_at_git_ref(root, base_ref, relative)
        new = _load_json(root / relative)
        compare_append_only_document(
            old,
            new,
            label=relative,
            list_key=list_key,
            mutable_on_append=mutable,
        )


def validate_repository(
    root: Path = REPOSITORY_ROOT,
    *,
    base_ref: str | None = None,
    tracked_files: set[str] | None = None,
) -> dict[str, int]:
    root = root.resolve(strict=True)
    if tracked_files is None:
        tracked_files = git_tracked_files(root)

    for schema_path in sorted((root / "schemas").glob("*.schema.json")):
        Draft202012Validator.check_schema(_load_json(schema_path))

    lock = _schema_validate_file(root, "upstream/stacks.lock.json", "schemas/upstream-lock.schema.json")
    leases = _schema_validate_file(root, "registry/leases.json", "schemas/lease-registry.schema.json")
    overlays = _schema_validate_file(root, "registry/overlays.json", "schemas/overlay-entry.schema.json")
    locales = _schema_validate_file(root, "registry/locales.json", "schemas/locale-registry.schema.json")
    releases = _schema_validate_file(root, "registry/releases.json", "schemas/release-manifest.schema.json")

    _validate_upstream_semantics(lock)
    issued, active = _validate_lease_lifecycle(root, leases, lock, tracked_files)
    pointers = _validate_pointers(root, issued, active, tracked_files)
    candidate_count = _validate_candidate_manifests(root, issued, lock, tracked_files)
    _validate_admission_registries(root, overlays, locales, releases, lock, tracked_files)
    if base_ref is not None:
        _validate_append_only_against_base(root, base_ref)

    return {
        "schemas": len(list((root / "schemas").glob("*.schema.json"))),
        "issued_leases": len(issued),
        "active_leases": len(active),
        "lease_pointers": len(pointers),
        "candidate_manifests": candidate_count,
        "overlays": len(overlays["registered_entries"]),
        "locales": len(locales["admitted_locales"]),
        "releases": len(releases["releases"]),
    }


def _parse_args(argv: Sequence[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=REPOSITORY_ROOT, help="repository root")
    parser.add_argument("--base-ref", help="Git ref whose registries must remain exact prefixes")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = _parse_args(sys.argv[1:] if argv is None else argv)
    try:
        counts = validate_repository(args.root, base_ref=args.base_ref)
    except RepositoryValidationError as exc:
        print(f"VALIDATION FAILED: {exc}", file=sys.stderr)
        return 1
    rendered = ", ".join(f"{key}={value}" for key, value in counts.items())
    suffix = f", append_only_base={args.base_ref}" if args.base_ref else ""
    print(f"VALIDATION PASSED: {rendered}{suffix}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
