from __future__ import annotations

import copy
import hashlib
import json
import shutil
import tempfile
import unittest
from pathlib import Path

from tools.validate_repository import (
    RepositoryValidationError,
    compare_append_only_document,
    git_tracked_files,
    validate_repository,
)


SOURCE_ROOT = Path(__file__).resolve().parents[1]
FIXTURES = SOURCE_ROOT / "tests" / "fixtures" / "negative"


def _read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _set_pointer(document, pointer: str, value) -> None:
    parts = pointer.removeprefix("/").split("/")
    cursor = document
    for part in parts[:-1]:
        cursor = cursor[int(part)] if isinstance(cursor, list) else cursor[part]
    last = parts[-1]
    if isinstance(cursor, list):
        cursor[int(last)] = value
    else:
        cursor[last] = value


def _hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


class RepositoryFixtureMixin:
    def make_repository(self) -> tuple[Path, set[str]]:
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name) / "repository"
        shutil.copytree(
            SOURCE_ROOT,
            root,
            ignore=shutil.ignore_patterns(".git", "__pycache__", "*.pyc"),
        )
        return root, set(self.base_tracked)


class CurrentStateTests(RepositoryFixtureMixin, unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.base_tracked = git_tracked_files(SOURCE_ROOT)

    def test_current_repository_is_valid_and_unadmitted(self) -> None:
        counts = validate_repository(SOURCE_ROOT, tracked_files=self.base_tracked)
        self.assertEqual(counts["issued_leases"], 3)
        self.assertEqual(counts["active_leases"], 3)
        self.assertEqual(counts["lease_pointers"], 3)
        self.assertEqual(counts["candidate_manifests"], 0)
        self.assertEqual(counts["overlays"], 0)
        self.assertEqual(counts["locales"], 0)
        self.assertEqual(counts["releases"], 0)

    def test_registry_negative_fixtures_fail_closed(self) -> None:
        cases = _read_json(FIXTURES / "registry_cases.json")
        for case in cases:
            with self.subTest(case=case["name"]):
                root, tracked = self.make_repository()
                target = root / case["target"]
                document = _read_json(target)
                _set_pointer(document, case["pointer"], case["value"])
                _write_json(target, document)
                with self.assertRaisesRegex(RepositoryValidationError, case["expected"]):
                    validate_repository(root, tracked_files=tracked)

    def test_valid_release_event_is_folded_instead_of_counting_stale_active_issue(self) -> None:
        root, tracked = self.make_repository()
        registry_path = root / "registry" / "leases.json"
        registry = _read_json(registry_path)
        transition = copy.deepcopy(registry["events"][0])
        transition.update(
            {
                "event_id": "lease-event-000004",
                "event": "released",
                "state": "released",
                "supersedes_event_id": "lease-event-000001",
                "event_at_utc": "2026-08-12T21:00:00Z",
            }
        )
        registry["events"].append(transition)
        _write_json(registry_path, registry)
        counts = validate_repository(root, tracked_files=tracked)
        self.assertEqual(counts["issued_leases"], 3)
        self.assertEqual(counts["active_leases"], 2)


class CandidateValidationTests(RepositoryFixtureMixin, unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.base_tracked = git_tracked_files(SOURCE_ROOT)

    def build_valid_candidate(self, root: Path, tracked: set[str]) -> tuple[Path, dict, set[str]]:
        candidate_relative = "candidates/commons/stacks/fac"
        candidate_root = root / candidate_relative
        payloads = {
            "source.txt": "Immutable source authority fixture.\n",
            "stable-units.json": '{"units":["fac.unit.0001","fac.unit.0002"]}\n',
            "source-map.json": '{"fac.unit.0001":"source:1","fac.unit.0002":"source:2"}\n',
            "decisions.jsonl": '{"id":"decision-0001","state":"accepted"}\n',
            "rejections.jsonl": '{"id":"rejection-0001","state":"preserved"}\n',
            "formula-diagrams.json": '{"formulas":0,"diagrams":0}\n',
            "build.txt": "mechanical validation passed\n",
        }
        records = {}
        for name, content in payloads.items():
            path = candidate_root / name
            path.write_text(content, encoding="utf-8")
            relative = path.relative_to(root).as_posix()
            tracked.add(relative)
            records[name] = {"path": relative, "sha256": _hash(path)}

        manifest = {
            "$schema": "schemas/candidate-manifest.schema.json",
            "schema": "mathematics-commons-stacks-candidate-manifest/v1",
            "candidate_id": "fac-fixture-v1",
            "lease_id": "stacks-lease-000001-fac",
            "namespace": "commons/stacks/fac",
            "writer_task": "019fca5a-c29e-7330-acdc-c93f4a3dc9fb",
            "upstream": {
                "lock": "upstream/stacks.lock.json",
                "commit": "a04446e57ec1fbc252a871afcec7752fb2807b14",
                "tree": "3feeb703b931a6e7259782c10e7d1575adc83e5e",
            },
            "source_authorities": [records["source.txt"]],
            "source_closure": {
                "enumerated": True,
                "expected_units": 2,
                "manifested_units": 2,
                "complete": True,
            },
            "stable_ids": ["fac.unit.0001", "fac.unit.0002"],
            "stable_unit_manifest": records["stable-units.json"],
            "source_map": records["source-map.json"],
            "decision_ledger": records["decisions.jsonl"],
            "rejection_ledger": records["rejections.jsonl"],
            "formula_diagram_inventory": records["formula-diagrams.json"],
            "builds": [records["build.txt"]],
            "file_inventory": list(records.values()),
            "rights_state": "fixture_only_not_for_admission",
            "review_state": "not_performed",
            "independent_replay": "not_performed",
            "unresolved_defects": [],
            "stop_conditions": ["fixture must never be admitted"],
            "generated_at_utc": "2026-08-12T21:00:00Z",
        }
        manifest_path = candidate_root / "candidate.manifest.json"
        _write_json(manifest_path, manifest)
        tracked.add(manifest_path.relative_to(root).as_posix())
        return manifest_path, manifest, tracked

    def test_complete_tracked_candidate_passes(self) -> None:
        root, tracked = self.make_repository()
        self.build_valid_candidate(root, tracked)
        counts = validate_repository(root, tracked_files=tracked)
        self.assertEqual(counts["candidate_manifests"], 1)

    def test_candidate_negative_fixtures_fail_closed(self) -> None:
        cases = _read_json(FIXTURES / "candidate_cases.json")
        for case in cases:
            with self.subTest(case=case["name"]):
                root, tracked = self.make_repository()
                manifest_path, manifest, tracked = self.build_valid_candidate(root, tracked)
                action = case["action"]
                if action == "evidence_path_escape":
                    manifest["decision_ledger"] = {
                        "path": "RIGHTS.md",
                        "sha256": _hash(root / "RIGHTS.md"),
                    }
                elif action == "hash_mismatch":
                    manifest["file_inventory"][0]["sha256"] = "0" * 64
                elif action == "untracked_file":
                    tracked.remove(manifest["source_authorities"][0]["path"])
                elif action == "inventory_omission":
                    omitted = manifest["builds"][0]["path"]
                    manifest["file_inventory"] = [
                        item for item in manifest["file_inventory"] if item["path"] != omitted
                    ]
                elif action == "unexpected_file":
                    (manifest_path.parent / "unexpected.tmp").write_text("adverse fixture\n", encoding="utf-8")
                elif action == "duplicate_inventory":
                    manifest["file_inventory"].append(copy.deepcopy(manifest["file_inventory"][0]))
                else:
                    self.fail(f"unknown fixture action: {action}")
                _write_json(manifest_path, manifest)
                with self.assertRaisesRegex(RepositoryValidationError, case["expected"]):
                    validate_repository(root, tracked_files=tracked)


class AppendOnlyTests(unittest.TestCase):
    def test_append_is_accepted(self) -> None:
        old = {"schema": "example/v1", "events": [{"id": 1}]}
        new = {"schema": "example/v1", "events": [{"id": 1}, {"id": 2}]}
        compare_append_only_document(old, new, label="fixture", list_key="events")

    def test_negative_append_only_fixtures_fail_closed(self) -> None:
        cases = _read_json(FIXTURES / "append_only_cases.json")
        for case in cases:
            with self.subTest(case=case["name"]):
                old = {"schema": "example/v1", "namespace": "commons/stacks", "events": [{"id": 1}]}
                new = copy.deepcopy(old)
                if case["action"] == "edit_prior_event":
                    new["events"][0]["id"] = 9
                elif case["action"] == "truncate":
                    old["events"].append({"id": 2})
                elif case["action"] == "rewrite_metadata":
                    new["namespace"] = "commons/other"
                else:
                    self.fail(f"unknown fixture action: {case['action']}")
                with self.assertRaisesRegex(RepositoryValidationError, case["expected"]):
                    compare_append_only_document(old, new, label="fixture", list_key="events")


if __name__ == "__main__":
    unittest.main()
