# Unofficial Stacks Project AI Drafts

[![Repository validation](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/actions/workflows/validate.yml/badge.svg)](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/actions/workflows/validate.yml)

## Why this project exists

This repository is a collection of unofficial, AI-written drafts for possible
later human use. It is not a campaign for the Stacks Project to accept AI
contributions, and it is not a claim that these drafts are ready to become
part of the canonical Stacks Project.

The practical idea is modest: editable LaTeX editions of important
French-school sources make it possible to compare those works with the Stacks
Project, identify material that may still be useful, and prepare draft
statements and proofs in Stacks-style LaTeX. The drafts are left here so that
Stacks contributors—or other mathematicians—can inspect, correct, reuse, or
mine them if and when someone with the relevant expertise has time to do so.

The inputs include editable LaTeX editions of major French-school works:

- **Serre, FAC — *Faisceaux algébriques cohérents*:** [French diplomatic TeX](https://zenodo.org/records/22074486/files/01b_FAC_French_Diplomatic_Body.tex?download=1) · [complete French/English source package](https://zenodo.org/records/22074486/files/19_FAC_Project_English_and_French_TeX_Source_Layers.zip?download=1).
- **Grothendieck, Tôhoku — *Sur quelques points d’algèbre homologique*:** [LaTeX source package](https://zenodo.org/records/22087339/files/src-p119-221.zip?download=1).
- **Serre, GAGA — *Géométrie algébrique et géométrie analytique*:** [French diplomatic TeX](https://zenodo.org/records/22087259/files/16_GAGA_French_diplomatic_body.tex?download=1) · [compilation driver](https://zenodo.org/records/22087259/files/15_GAGA_French_shared_driver_for_diplomatic_and_corrected.tex?download=1).
- **Grothendieck, FGA — *Fondements de la géométrie algébrique*:** [French LaTeX source and provenance package](https://github.com/KokunoYumeto/fga-fr/blob/main/releases/2026-08-30-r1/fga-fr-canon-errata-0001-0017-source-provenance.zip).
- **Grothendieck–Dieudonné, EGA — *Éléments de géométrie algébrique*:** [French LaTeX tree](https://github.com/KokunoYumeto/ega-fr/tree/main/source) · [English discovery edition](https://github.com/KokunoYumeto/ega-en/tree/main/source).
- **Verdier, *Des catégories dérivées des catégories abéliennes*:** [editable source package](https://zenodo.org/records/21968574/files/source.zip?download=1).

These are independently maintained transcriptions or editions, not original
author-produced LaTeX. The integration records pin the particular source
versions used; the linked editions may continue to develop.

We understand why a human-maintained project may choose not to rely on
AI-generated material. Maintaining mathematics requires people who can
understand, explain, repair, and extend the proofs; producing a plausible
draft does not transfer that expertise to its future maintainers. Until a
qualified reader has checked an addition and is prepared to understand and
maintain it, it should be treated as an external draft—not as part of the
human-maintained Stacks corpus.

> [!IMPORTANT]
> This is an unofficial, independently maintained draft derivative of the
> [Stacks Project](https://stacks.math.columbia.edu/), not a competing canonical
> edition. All additions and integration work beyond the pinned upstream
> source are written by cooperating AI agents; the original Stacks text is
> the work of its authors. The Stacks Project and its maintainers have not
> reviewed, approved, or endorsed this project. “Draft formalization” here
> means mathematical statements and written proofs in LaTeX—not
> proof-assistant-checked mathematics. Automated checks and AI review do not
> certify mathematical correctness.

[Read the draft PDFs](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/releases/latest) ·
[Browse the source](chapters.tex) ·
[Possible fixes](PROPOSED_CORRECTIONS.md) ·
[Possible new additions](POSSIBLE_ADDITIONS.md) ·
[Compare with Stacks](CHANGES_FROM_UPSTREAM.md) ·
[Detailed status](STATUS.md) ·
[Development program](ROADMAP.md) ·
[Sources and history](PROVENANCE.md) ·
[Validation](VALIDATION.md)

## Two separate lists: possible fixes and possible new additions

- **[Corrections-only downloads from the integrated batches](upstream-corrections/README.md):**
  one combined patch or separate chapter patches, with exact changes and review
  evidence. These do not import our theorem additions or repository history.
  The 1,641 historical correction IDs are accounted for; 1,639 effective textual
  units are exported, with one superseded correction and one fork tag allocation
  explicitly excluded. No clone of this fork is needed.
- **[Possible fixes to existing Stacks text](PROPOSED_CORRECTIONS.md):**
  original location, smallest replacement, and a short reason. The readable
  selection also has [standalone patches](possible-fixes/README.md), checked
  against the pinned official source; none requires adopting our additions.
- **[Possible new additions](POSSIBLE_ADDITIONS.md):** source work, named
  theorem or construction, proof location, and actual integration status.
  These may be inspected independently, or ignored entirely when reviewing fixes.

The [proposed-corrections log](PROPOSED_CORRECTIONS.md) gives the original
passage, the smallest proposed replacement, and a short argument that a reader
can check. It distinguishes mathematical errors from typos, pending proposals
from changes already in this draft, and duplicate or withdrawn suggestions.
These are **AI-reviewed proposals, not expert-approved or officially adopted
Stacks errata**. The readable log is being expanded; its stated coverage is
not a claim to cover every finding from the translations or historical work.
The [complete recorded comparison](CHANGES_FROM_UPSTREAM.md) remains available
alongside it. Neither list treats an added theorem as an upstream correction.

The original 13-item readable selection is not the total correction collection.
All thirteen are now integrated in this draft: two limit-preservation fixes
in R50 and the remaining eleven in R51. They are also in the larger export;
do not apply the same fix twice. Upstream adoption is not claimed.
Both sets target the pinned official revision. The official master ref was
[checked on 25 September 2026](validation/upstream-ref-check-2026-09-25.json)
and still matched that revision; later upstream compatibility requires a new check.

The source and fixes-only downloads include R49: five de Rham corrections
(seven edits), including balanced parentheses in the Hodge-filtration cup-product
diagram and four small prose repairs. The latest full-reader release predates
these edits; this is a source-and-patch update, not a new Zenodo edition.
R50 adds two corrections in **Limits of Algebraic Spaces**: using the fibre
point fixed in the proof, and citing finite limits rather than only finite
products for a fibre-product comparison. The [33 chapter patch sets](upstream-corrections/README.md)
include both, with no added theorems. The bounded chapter proof and complete
editable source are linked in [its candidate record](ai-integrated/candidates/commons/stacks/errata/r50/README.md).

R51 adds **29 corrections** in Sets, Schemes, Homology and Algebra. These include
the reversed maps and compositions in the Ext resolution-independence proof,
the differential index in a chain map, both split-sequence endpoint modules,
the ordinal bound on a prescribed family of coverings, and the denominator
defining the coordinate ring of GL(2). Smaller sheaf-domain, diagram and English
repairs are individually explained in [the correction review](ai-integrated/candidates/commons/stacks/errata/r51/REVIEW.md).
[Chapter proofs and complete editable sources](ai-integrated/candidates/commons/stacks/errata/r51/README.md)
accompany the batch; the fixes-only downloads contain no theorem additions.
This remains a source-and-patch update, not a new Zenodo edition.

R52 adds **83 proposed changes in Categories**: 51 copyedits, 11 clarifications
and 21 source corrections, not 83 new mathematical errors. Examples include the
endpoint in the definition of an initial functor, the cone-component indices in
the finite-limit proof, a common-refinement index for pro-objects, the coherence
maps for a 2-fibre product, and an inverse missing from a comparison of fibred
categories. [Exact changes and reasons](ai-integrated/candidates/commons/stacks/errata/r52/REVIEW.md)
and [proofs with complete editable sources](ai-integrated/candidates/commons/stacks/errata/r52/README.md)
are available. The intake record also preserves rejected suggestions and
duplicates. These changes are included in the Categories patch and combined
fixes-only download; no theorem additions are required.

R53 adds **54 proposed changes in Topology and Introduction**: 44 copyedits,
five clarifications, four notation clarifications and one source correction.
They explicitly restrict the map in the connected-image proof, restore a
missing inclusion in a dimension chain, and clarify the scope of set operations.
[Exact changes and reasons](ai-integrated/candidates/commons/stacks/errata/r53/REVIEW.md)
and [reviewed chapter PDFs with complete editable sources](ai-integrated/candidates/commons/stacks/errata/r53/README.md)
are available. The combined fixes-only download now covers 34 chapters.
The older complete-reader PDFs are unchanged by this source-and-patch update.

R54 adds **12 proposed Sheaves on Spaces changes**: eleven copyedits and
one clarification. The fibre-product argument now identifies the invertible
projection and constructs the required factorization using its inverse.
The wording repairs include missing naming prepositions and a stale claim
that a definition was left to the reader. [Each change and its reason](ai-integrated/candidates/commons/stacks/errata/r54/REVIEW.md)
and [chapter PDFs with complete editable sources](ai-integrated/candidates/commons/stacks/errata/r54/README.md)
are available. The Sheaves patch and combined fixes-only download include
all sixteen edits and retain the earlier corrections.

R55 adds **29 proposed Sites and Sheaves changes**: 22 copyedits, five
source corrections and two clarifications. The corrections restore the
cohomology-set terminology, a sheafification sign, a presheaf target,
a transition-map index and the covering-sieve references used in two proofs.
The clarifications specify composition grouping and an element-to-stalk
assignment. [Exact changes and reasons](ai-integrated/candidates/commons/stacks/errata/r55/REVIEW.md)
and [chapter PDFs with complete editable sources](ai-integrated/candidates/commons/stacks/errata/r55/README.md)
are available. The Sites patch and combined fixes-only download contain
all 35 edits and retain the 107 earlier Sites corrections.

R56 adds **76 proposed Stacks corrections and clarifications**: 34 copyedits,
35 source corrections and seven clarifications. The substack criterion now
requires the necessary isomorphism in the correct fibre. The localization
criterion now detects cartesian arrows after an allowed refinement, with
a complete proof and counterexample to the previous converse. The edits
also restore missing comparison maps, composition factors and base labels.
[Exact changes and complete mathematical evidence](ai-integrated/candidates/commons/stacks/errata/r56/REVIEW.md)
and [chapter PDFs, direct LaTeX and reproducible sources](ai-integrated/candidates/commons/stacks/errata/r56/README.md)
accompany all 86 edits. They are included in the Stacks chapter patch and
combined corrections-only download.

R57 adds **47 proposed Fields corrections and clarifications**: 21 copyedits,
21 source corrections and five clarifications, across 56 exact edits.
They repair field and quotient domains, polynomial arguments, characteristic-zero
cases and a dropped Kummer sign. A complete proof of the normal algebraic
decomposition replaces an omitted argument; the transcendence-basis extension
property already proved in the source is now stated explicitly.
[Exact changes and reasons](ai-integrated/candidates/commons/stacks/errata/r57/REVIEW.md)
and [chapter PDFs, direct LaTeX and reproducible sources](ai-integrated/candidates/commons/stacks/errata/r57/README.md)
are available. The accompanying proof check also derives linear disjointness
without normality, preservation of both degrees and the canonical topological
Galois-group comparison; these consequences carry no novelty claim.
All eight earlier Fields fixes remain in the chapter and combined patches.

R52/R53/R54/R55/R56/R57 review, correction preparation, builds and visual checks, and current
correction-export tooling and packaging were produced by OpenAI Codex —
GPT-6 Astra, Ultra effort. This attribution concerns the export work, not a new
mathematical or human review of every historical correction; historical evidence
retains its original provenance.

[Two Pursuing Stacks modules](pursuing-stacks/README.md) are separately
readable: categories of elements and a conditional localization criterion;
then the sieve-cutoff contraction, sufficient asphericity criterion, and
abstract homotopy intervals. They contain fifteen statements with proofs
across two six-page readers, each with complete direct LaTeX and a reproducible
source ZIP. This is not a
claim that the whole historical work, or even the received 68-page draft, has
been integrated; it is not yet part of the older cumulative PDFs.

## Reading Stacks in other languages

Separately maintained AI-produced translations offer another route into the
Stacks Project for readers across research communities:

- [Chinese](https://github.com/KokunoYumeto/stacks-zh-hans-cn) · [translation-choice log](https://github.com/KokunoYumeto/stacks-zh-hans-cn/blob/9b1fec35dbf684e7c388eafb31c70a82986d23f2/review/translation-choices/README.md).
- [Japanese](https://github.com/KokunoYumeto/stacks-ja-jp) · [translation-choice log](https://github.com/KokunoYumeto/stacks-ja-jp/blob/72d82226a88909698e7902614e9c2d1f428c9714/review/translation-choices/README.md).
- [Korean](https://github.com/KokunoYumeto/stacks-ko-kr) · [translation-choice log](https://github.com/KokunoYumeto/stacks-ko-kr/blob/d0d0958de85104bb97c08895c4bd78ee14bbee04/review/translation-choices/README.md).

These translations have not received comprehensive expert human review.
Corrections to terminology, meaning, and exposition from knowledgeable readers
are warmly welcome. The linked logs distinguish consulted evidence from
provisional choices and historical records; their present scope is selected
Chapter 11 choices, not every choice throughout Stacks.

These are separate translation editions, not translated versions of every
addition in this AI-draft repository. Translation choices, proposed corrections
to the English source, and new mathematical exposition have separate records.

## What is actually in the draft?

The examples below name classical results and explain what was added here.
They are not claims that the underlying mathematics is new. **Integrated**
means the statement and proof are present in this branch’s readable LaTeX,
not merely mentioned in a tracking file.

### FAC: new explicit statements, proofs, and source corrections — integrated

The full article has been compared with Stacks. Results already covered were
mapped rather than rewritten; selected missing formulations and proofs were
added. Notable examples include:

- **Graded local duality** — Chapter III §4, no. 72, Theorem 1: an explicit
  graded-module formulation relating Koszul–Čech cohomology to graded Ext,
  including the exceptional kernel–cokernel sequence and its degree range.
  [Statement and proof](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/more-algebra.tex#L7692).
- **Cohomology of projective complete intersections** — Chapter III §5,
  no. 78, Proposition 5: calculations for all twists, intermediate-cohomology
  vanishing, and top-cohomology duality. The draft separates the
  zero-dimensional exception to the source’s section-isomorphism claim and
  supplies the appropriate exact sequence.
  [Statement, correction, and proof](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/coherent.tex#L4774).
- **Degree of the Hilbert polynomial equals dimension of support** —
  Chapter III §6, no. 81, Proposition 6: a consolidated statement and proof
  over an arbitrary field, assembled from existing Stacks ingredients.
  [Statement and proof](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/varieties.tex#L7018).

[Full FAC comparison and integration record](fac/STATUS.md).

### GAGA: the projective algebraic–analytic comparison — integrated chapter

The new [GAGA chapter](gaga.tex) develops Serre’s three central theorems from
§3, no. 12:

- **Cohomology comparison:** algebraic and analytic coherent-sheaf cohomology
  agree on complex projective varieties.
  [Theorem 1](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/gaga.tex#L1051) · [proof](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/gaga.tex#L1236).
- **Full faithfulness:** analytic homomorphisms between analytified coherent
  sheaves come uniquely from algebraic homomorphisms.
  [Theorem 2](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/gaga.tex#L1071) · [proof](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/gaga.tex#L1309).
- **Algebraization:** every coherent analytic sheaf on a complex projective
  variety comes from an algebraic coherent sheaf. The argument develops
  analytic twisting and global generation before algebraizing a finite
  presentation.
  [Theorem 3](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/gaga.tex#L1087) · [global-generation argument](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/gaga.tex#L1444).

Applications include [Chow’s theorem](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/gaga.tex#L1660) and
[algebraicity of holomorphic maps](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/gaga.tex#L1748).
This does **not** reconstruct every analytic foundation: Oka–Cartan coherence,
Weierstrass theory, Dolbeault computations, and related external inputs are
identified explicitly. [Scope and source comparison](gaga_r3/STATUS.md).

### FGA: Quot schemes, algebraization, and categorical foundations — integrated

- **Projective Quot schemes** — Exposé 221, Theorem 3.2 and Proposition 3.8:
  a Grassmannian construction proves that the fixed-Hilbert-polynomial Quot
  space is a projective scheme, with a very ample determinant bundle. This
  strengthens the inherited proper-algebraic-space conclusion in this setting.
  [Theorem and proof](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/moduli.tex#L1573).
- **Algebraizing formal families and lifting smooth varieties** — Exposé
  182, Theorem 4 and Corollaries 3–4: algebraization with projective special
  fibre and vanishing second structure-sheaf cohomology, followed by a
  deformation-theoretic lifting criterion and the smooth-curve case.
  [Algebraization](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/coherent.tex#L9031) ·
  [lifting criterion](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/defos.tex#L2536) ·
  [curves](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/defos.tex#L2603).
- **Recovering categories and groupoids from their nerves** — Exposé 212,
  Proposition 4.1 and Corollary 4.2: full faithfulness of the nerve, the Segal
  characterization of its image, and the equivalence “groupoid iff nerve is
  Kan,” including an internal finite-limit version.
  [Nerve and Segal theorem](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/simplicial.tex#L953) ·
  [groupoid/Kan theorem](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/simplicial.tex#L5796).

[Full FGA comparison and notation-normalization record](fga/README.md).

### EGA: selected scheme-theoretic additions — partial, ongoing

EGA is **not fully integrated**. This tree's reviewed comparison reaches
EGA I §7.4.7, including rational-function sheaves, torsion-free modules,
generic embeddings, and support criteria. We are now comparing coverage
across EGA before choosing further additions. The separate
[§8.1 comparison](ega/coverage/ega-i-8-1.md) identifies three results already
supplied by Stacks and two candidate combined statements; it does not claim
five new theorems or complete coverage of EGA.
The [§§8.2–8.3 comparison](ega/coverage/ega-i-8-2-3.md) explains how embedded
local rings recover an integral separated scheme, including the affine
overlap/gluing argument left to the reader in EGA. Eight numbered objects have
complete derivations from existing Stacks results; two further comparisons
record necessary empty-set conventions.
The [§9 comparison](ega/coverage/ega-i-9.md) now records 42 correspondences
for quasi-coherent sheaves, extension, and scheme-theoretic images, with two
explicit wording qualifications. It reuses existing Stacks results instead
of presenting 44 comparison objects as 44 new theorems.
The [EGA III §5 comparison](ega/coverage/ega-iii-5.md) finds Grothendieck
existence, formal-morphism algebraization, and ample-line-bundle algebraization
already in Stacks: 23 supported mathematical units, with an explicit
counterexample explaining the separatedness qualification in one further
passage. The [III §§6.2 and 6.10 comparison](ega/coverage/ega-iii-6-2-10.md)
explains finite-free cohomology representatives and arbitrary base change,
including the finite-projective degree bound for a single flat coherent sheaf.
It supports seven mathematical units and retains five precise questions about
unbounded constructions; neither comparison is a claim of complete EGA III.
The [III §§7.7–7.9 comparison](ega/coverage/ega-iii-7-7-9.md) explains 30
supported items on exactness and base change, coherent representing modules,
and Euler characteristics and Hilbert polynomials. It includes the
infinitesimal length criterion and the weaker separable-global-sections
hypothesis for degree-zero cohomological flatness. A subsequent
[global-hypertor comparison](ega/coverage/ega-iii-7-7-12-hypertor.md) identifies
the historical nonflat coefficient functor and its exchange map; it explains
why ordinary geometric pullback is a different operation and supplies a
counterexample to that replacement. The selected tally is now 30 supported,
one qualified and one awaiting root-source integration. A new
[Picard cotangent and jumping-family proof draft](ega/coverage/ega-iii-7-8-10-picard.md)
identifies the representing module for all coefficients and constructs a
smooth projective family whose $h^1(\mathcal O)$ jumps from 1 to 2 in
characteristic two. The example is an explicit candidate addition, not yet
a theorem in the cumulative LaTeX chapters. The earlier coverage matches
are correspondences with existing Stacks mathematics, not new theorems.
A [supplement on III.7.7.9](ega/coverage/ega-iii-7-7-9-representability.md)
explains base change of the representing modules and removes the global
two-term presentation hypothesis using Stacks' Ext-functor construction.
It also gives an existing Stacks counterexample to the unrestricted global
reading of the relative-ampleness remark, while retaining its valid local form.
The [IV §18.12 comparison](ega/coverage/ega-iv-18-12.md) records 16 supported
items on finiteness, Zariski's Main Theorem, normalization and ampleness. It
separates a historical conjecture and an unchecked proof-route claim from
actual missing-theorem candidates, and explains the local shrinking and
full-section-ring hypotheses needed in the less immediate arguments.
The earlier §6.6.4 contribution
completes the base-change proof for quasi-compact morphisms at Stacks tag
01K5. Sections 6.6.5–6.6.8 connect the generic-point criterion for dominance,
permanence of locally finite-type morphisms, locally Noetherian fibre products,
and geometric-point tests to existing Stacks results, with their precise
hypotheses retained. These comparisons add no duplicate root theorem.
Sections 7.1.1–7.1.3 explain rational maps, rational sections, and the ring
of rational functions using the existing Stacks definitions. The comparison
also corrects an overstatement in EGA's printed restriction argument:
representatives agree on a dense open witness, not necessarily on their
entire overlap. The original remains available for comparison; the draft
gives the corrected argument and an explicit counterexample to the stronger
claim. See the [rational-map comparison](ega/README.md#rational-maps-and-functions).
Sections 7.1.4–7.1.9.1 identify rational maps with germs at generic points,
express rational functions as a finite product of generic local rings, and
deduce Artinianness for Noetherian schemes. For an affine scheme with finitely
many components, they identify rational functions with localization away from
the minimal primes—not automatically the total quotient ring. The
[written comparison](ega/i719.md) gives the derivations, their precise
hypotheses, and counterexamples; these results reuse existing Stacks content.
Sections 7.1.10–7.1.14 explain when a rational map is determined by its
generic local scheme, distinguish finite-type uniqueness from
finite-presentation existence, and show why localization at a point preserves
the rational-map set under the stated hypotheses. The [comparison](ega/i714.md)
keeps the base-scheme structure and possible nilpotents explicit.
The concluding corollaries 7.1.15–7.1.16 identify rational maps from an integral
scheme with points valued in its function field. The [comparison](ega/i716.md)
retains the chosen residue-field embedding and its compatibility with the base.
It also explains why EGA's historical “geometric point” here is not the modern
algebraically-closed-field convention. Existing Stacks results apply under weaker
hypotheses; no duplicate theorem or formal-proof claim is introduced.
Sections 7.2.1–7.2.4 explain the largest domain on which a rational map
can be represented. The [comparison](ega/i724.md) distinguishes ordinary
maps from maps over a fixed base: their largest domains can differ, even
for affine charts of a scheme with two origins. It gives the complete
dense-agreement and gluing arguments, and explains why a separated base
restores compatibility. This is a careful comparison of existing results,
not an assertion that the source's unqualified wording is always equivalent.
Sections 7.2.5–7.2.7 show that a rational section remains a section on its
base-preserving domain, identify regular functions on a dense open with
rational functions defined there, and characterize extension of a section
by whether its reduced closure maps isomorphically to the base. The
[complete comparison](ega/i727.md) proves both directions of that criterion
without adding a retrocompactness assumption, and gives examples showing why
ordinary extensions need not be extensions as sections. These are explicit
derivations from existing Stacks results, not new root theorems.
Sections 7.2.8–7.2.9 establish when a rational map extends near a point:
the induced rational map on the local scheme must extend as a morphism
over the same base. The [complete comparison](ega/i729.md) proves the
component and density lemma, the local spreading step, and the final gluing
argument. An explicit nonfinite-normalization example shows why an ordinary
local morphism is not enough. These are derivations from existing Stacks
results, with the source's hypotheses and stronger available results kept distinct.
Sections 7.3.1–7.3.4 construct the sheaf of rational functions from regular
functions on dense open sets, prove its compatibility with restriction, and
describe it using the local rings at generic points. The
[complete comparison](ega/i734.md) supplies the gluing and localization
arguments needed for quasi-coherence and the decomposition into component
function fields for reduced schemes with finitely many components. It also
explains a genuine distinction:
on a nonreduced scheme, EGA's dense-open rational functions need not be the
meromorphic functions formed by inverting nonzerodivisors. An explicit example
shows how a nonzero nilpotent can disappear in the former but not the latter.
These are written derivations from existing Stacks results, not new official
theorems or machine-checked proofs.
The later [§7.3.5–7.3.7 comparison](ega/i737.md) treats modules over the
rational-function sheaf. The [§7.3.8 comparison](ega/i738.md) uses EGA II's
published replacement of the original pullback assertion. Finally, the
[§7.4 comparison](ega/i74.md) supplies the torsion and support arguments,
repairs an overbroad tensor assertion under explicit quasi-coherence
hypotheses, and adopts the already-published EGA III erratum for the
proper-support claim. These source corrections, existing Stacks results,
and independently written draft proofs are kept distinct.
See the [validation and publication states](STATUS.md).
Other concrete additions already in the draft include:

- **The Jacobson-radical neighbourhood lemma** — EGA I, Proposition 1.1.15:
  an open subset of an affine spectrum containing the closed set of an ideal
  in the Jacobson radical is the whole spectrum.
  [Named lemma and proof](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/algebra.tex#L3628).
- **A spectrum-embedding criterion** — EGA I, Corollary 1.2.4:
  a unit-times-image condition on a ring map makes its spectrum map a
  homeomorphism onto its image.
  [Statement and proof](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/algebra.tex#L3172).
- **Four equivalent quasi-coherence criteria** — EGA I, Theorem 1.4.1:
  a consolidated theorem for quasi-compact opens of affine schemes, relating
  extension from an ambient module and localization of global sections.
  [Statement and proof](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/properties.tex#L2483).

[Detailed coverage and remaining work](ega/README.md).

### Verdier: an obstruction to functorial cones — one proposition integrated

**Astérisque 239, Chapter II, Proposition 1.2.13:** a functorial choice of
distinguished cone triangles, together with countable products or coproducts,
forces every morphism to decompose as a split projection followed by a split
inclusion. The draft adds the functoriality argument and connects it to
existing Stacks results on splitting idempotents and decomposability.
[Statement and proof](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/blob/6c5f549dcdec6051dfeaf0e5300faf3b80576830/derived.tex#L825).
This is one bounded contribution, not an integration of the whole thesis.

### Illusie I: chain comparison and localization — partial integration

The [Simplicial Methods source](simplicial.tex) contains independently written
drafts from the opening of *Complexe cotangent et déformations I*:

- **Eilenberg–Zilber comparison:** Alexander–Whitney and shuffle maps compare
  diagonal and total complexes, with the signs, grading and two natural chain
  homotopies written out. The corrected draft removes our earlier false claim
  of a strict inverse on unnormalized chains.
  [Formulas and proof](illusie_volume_I/relative-homotopy.tex).
- **Localization and derived functors:** the §I.1.4 draft develops the
  essentially constant pro-object construction and explains how Dold–Kan
  passes to the derived category with a fixed nonpositive degree bound.
  [Statements and proofs](illusie_volume_I/localization.tex).

This is not the whole volume. The comparison inventory reaches printed pages
1–16; the normal/degenerate comparison on page 11 remains explicitly pending.
The [correction and build-history note](validation/illusie-build-history-correction-2026-09-13.md)
distinguishes the repaired source from older PDFs; [current validation and
publication status](STATUS.md) is recorded separately.

### Tôhoku: substantial comparison and draft-proof work — not fully integrated

The preserved research dossier records work on difficult parts of
Grothendieck’s paper, including **right satellites under injective-effacement
hypotheses** (Theorem 2.2.2), **Leray spectral sequences with families of
supports** (Theorem 3.7.3), and **equivariant Čech comparison and Ext spectral
sequences** (Theorems 5.5.6 and 5.6.3).

However, several proofs referenced by that historical dossier are absent from
this branch’s current LaTeX. The composite-functor spectral sequence here also
still has stronger hypotheses than the dossier’s proposed version.
**The entire paper must not be counted as integrated.** Results already in
official Stacks—such as enough injectives in a Grothendieck category—are
existing coverage, not AI contributions.
[Preserved dossier](tohoku_r71/STATUS.md) ·
[Concrete integration gap](ROADMAP.md#tohoku-source-integration-gap).

### Corrections to the inherited Stacks text — integrated with comparisons

The draft also corrects mathematical typing, indices, references, and prose.
Examples include:

- **Groupoid modules and abelian varieties:** restoring the order of the two
  inverse-composition identities, and treating multiplication by zero
  separately in the proof of the étaleness criterion.
  [Inverse identities](CHANGES_FROM_UPSTREAM.md#mc-stk-err-1568) ·
  [Zero-multiplication case](CHANGES_FROM_UPSTREAM.md#mc-stk-err-1564).
- **Derived categories of algebraic spaces:** correcting the left-exactness
  statement used in Mayer–Vietoris, the fibre product on which a restriction
  is taken, and the source or target of several derived functors.
  [Mayer–Vietoris](CHANGES_FROM_UPSTREAM.md#mc-stk-err-1551) ·
  [Restriction](CHANGES_FROM_UPSTREAM.md#mc-stk-err-1562) ·
  [Functor domains](CHANGES_FROM_UPSTREAM.md#mc-stk-err-1554).
- **Naive cotangent-complex functoriality:** correcting which cotangent
  complex is pulled back and which is the target of the comparison map.
  [Original and replacement](CHANGES_FROM_UPSTREAM.md#mc-stk-err-1214).
- **Localization at an object of a site:** using the sheaf category of the
  slice site in place of an unrelated quotient topos in the proof.
  [Original and replacement](CHANGES_FROM_UPSTREAM.md#mc-stk-err-1287).
- **Functoriality of derived internal Hom:** restoring a missing arrow in a
  distinguished triangle and correcting the direction of a comparison map.
  [Triangle](CHANGES_FROM_UPSTREAM.md#mc-stk-err-1297) ·
  [comparison map](CHANGES_FROM_UPSTREAM.md#mc-stk-err-1312).
- **Commutative-algebra proofs:** repairing mismatched ring indices,
  localization subscripts, and the use of all minimal primes in a
  reduced-ring injection. These are local corrections, not replacement
  proofs of the entire chapter.
  [Chapter-by-chapter comparisons](ai-integrated/changes/index.html).

Not every edit is a mathematical error correction: some improve prose or
normalize equivalent notation. For example, the two summation conventions
in [MC-STK-ERR-1345](CHANGES_FROM_UPSTREAM.md#mc-stk-err-1345) mean the same
thing. [The classification clarification](ai-integrated/registry/admission-receipts/r38-clarification-0001.json)
records that distinction explicitly.

[Browse every recorded correction](CHANGES_FROM_UPSTREAM.md). This comparison
places the pinned original beside the replacement and links the source,
rationale, and review evidence. The [offline HTML browser](ai-integrated/changes/index.html)
adds search and chapter filters. The original
[official Stacks snapshot](https://github.com/stacks/stacks-project/tree/a04446e57ec1fbc252a871afcec7752fb2807b14)
remains directly accessible.

## Read, inspect, and reproduce

Start with a theorem above, inspect its proof and dependencies, then compare it
with the historical source and the upstream Stacks text. There is no expectation
that a reader accept a result because an AI or an automated check produced it.

- [Latest readable PDF/source package](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/releases/latest)
  · [Zenodo preservation lineage](https://doi.org/10.5281/zenodo.22135180).
- GitHub is the incremental working record. Zenodo is reserved for substantial,
  coherent milestones—such as a large integrated source tranche or a major
  cumulative errata release—not individual theorems or routine weekly updates.
- [Public EGA I §6.6.4 source checkpoint](validation/ega-i-6.6.4-source-checkpoint-2026-08-31.json)
  · [§6.6.6–6.6.8 comparison and validation](validation/ega-i-6.6.6-6.6.8-integration-validation-2026-09-07.json).
- [Build and validation instructions](VALIDATION.md)
  · [exact current build evidence](validation/README.md).
- [Complete project status](STATUS.md) · [roadmap](ROADMAP.md)
  · [source provenance and preserved histories](PROVENANCE.md).

The inherited build entry point remains:

~~~sh
make pdfs
~~~

The repository integrity check is:

~~~sh
python tools/validate_unified_repository.py --pre-publication
~~~

## Attribution and licensing

The pinned Stacks source and this modified source are distributed under the
GNU Free Documentation License 1.2; see [COPYING](COPYING).
Registry metadata and schemas have the separate, narrow rights statement in
[ai-integrated/RIGHTS.md](ai-integrated/RIGHTS.md). Source-edition links above
do not imply common licensing or endorsement by the original authors.
