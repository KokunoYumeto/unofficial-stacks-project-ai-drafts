Verdier II.2.3.1 candidate PDF — exact editable source
=======================================================

This archive reproduces the candidate QA artifact
`ai-integrated/candidates/commons/stacks/verdier-ast239-2-3-1-r1/builds/derived.pdf` (1269159 bytes; SHA-256 A734E873ACD868482884E05E07E14C4F587CB29DDA91AED8F8C985A5DAE323B6).

The base is commit 22dd577923c0faa54474021bc7de93a467aa1f47, tree e47b62074035be104f95aaa29c49ac2249a7fa9c.  `derived.tex` is the exact
insertion-only postimage of operation VDR-STK-COMP-0003; all other included source
files are byte-exact base-commit files.  The eight stems used by the recorded build
are sets, categories, algebra, homology, more-algebra, injectives, examples, and
derived.  No unrelated external auxiliary files are required; the original build
held them absent in both its baseline and candidate runs.

Build from this directory with pdfLaTeX and BibTeX.  Prime each of the eight stems
once with pdfLaTeX, run BibTeX once for each stem, then run global pdfLaTeX sweeps
over the stems in the order above until the PDF/AUX/TOC/OUT/BBL vector is unchanged
on two consecutive sweeps (maximum six).  The recorded environment used MiKTeX
pdfTeX 4.27 and BibTeX 4.2 with `SOURCE_DATE_EPOCH=1790578563` and timezone UTC.

AI typesetting and mathematical translation/correction for the inserted material:
OpenAI Codex — GPT-5.6 Sol, Ultra effort.  No human review is claimed.
