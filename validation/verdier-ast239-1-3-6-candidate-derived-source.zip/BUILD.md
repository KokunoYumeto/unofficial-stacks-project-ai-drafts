Verdier II.1.3.6 candidate PDF — exact editable source
=======================================================

This archive reproduces the candidate QA artifact
`ai-integrated/candidates/commons/stacks/verdier-ast239-1-3-6-r1/builds/derived.pdf` (1251089 bytes; SHA-256 1B45A53DFDC6394AB795855172915794F20634953361E8596AF17FC2E6F97331).

The base is commit f73b18165c7162b8386de06cc3c50bd4ced745b6, tree 5bc25c775349eddf5fa90a7f37f5b11044d89ec1.  `derived.tex` is the exact
insertion-only postimage of operation VDR-STK-COMP-0002; all other included source
files are byte-exact base-commit files.  The eight stems used by the recorded build
are sets, categories, algebra, homology, more-algebra, injectives, examples, and
derived.  No unrelated external auxiliary files are required; the original build
held them absent in both its baseline and candidate runs.

Build from this directory with pdfLaTeX and BibTeX.  Prime each of the eight stems
once with pdfLaTeX, run BibTeX once for each stem, then run global pdfLaTeX sweeps
over the stems in the order above until the PDF/AUX/TOC/OUT/BBL vector is unchanged
on two consecutive sweeps (maximum six).  The recorded environment used MiKTeX
pdfTeX 4.27 and BibTeX 4.2 with `SOURCE_DATE_EPOCH=1788641805` and timezone UTC.

AI typesetting and mathematical translation/correction for the inserted material:
OpenAI Codex — GPT-5.6 Sol, Ultra effort.  No human review is claimed.
