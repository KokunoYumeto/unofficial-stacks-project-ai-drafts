# Tensor criteria, coherent rings and countable projectivity

Separate editorial evidence for the Stacks Project authors' `algebra.tex`, authority commit `a04446e57ec1fbc252a871afcec7752fb2807b14`, lines 21442–22460. Authority SHA-256: `FA8BB92E58A4F78A2BD01B3B6A4A87DE0A0D279F5DD90641B574DD5FBFFFA4F3`. All nineteen due reports and all complete source units in this interval were read. The next theorem's statement at 22461–22465 was read only as lookahead; its proof remains unread.

The source's Chase citation and its attribution of the faithfully flat ML argument to Juan Pablo Acosta Lopez are retained. Those citations are not claims of independent reading of the cited works or correspondence. Four already composed corrections, `MC-STK-ERR-0451` through `0454`, account for eight reports and six operations. Ten further minimal operations are proposed, and the false article report is rejected. Full supporting proofs and the two further consequences remain separate editorial material; the source statements and original hypotheses remain identifiable. No chapter or translation mutation, novelty claim, or later synthesis completion is asserted.

## The tensor criterion and its receiving diagrams

Source 21442–21687. The tensor criterion is correct with the ML characterization previously repaired in groups 505–506. For its forward direction, represent the original kernel element by \(x_i\in M_i\otimes\prod Q_\alpha\), and choose one \(j\geq i\) for which \(f_{ij}\) and \(f_i\) have equal tensor kernels for every test module. The coordinates of the comparison image of \(x_i\) vanish in \(M\otimes Q_\alpha\), hence in \(M_j\otimes Q_\alpha\). The finite-presentation product comparison for \(M_j\) is injective, so the image of \(x_i\) at that stage is zero. Thus the original colimit element is zero.

For the converse, finite presentations are specified by finite matrices with entries in the set \(R\), so their isomorphism classes have a set of representatives. The source's set of pairs \((Q,x)\), with \(x\in\ker(P\otimes Q\to M\otimes Q)\), is therefore a set. Retain its entire product, including all such kernel elements. The finite-presentation comparison for \(P\) lifts the tuple of these elements to one element \(x\in P\otimes\prod Q_\alpha\). The assumed injection for \(M\) makes its image zero. The already reviewed kernel-witness lemma factors \(P\to M\) through a finitely presented \(P'\) killing that one product element. Projecting to every coordinate kills every original finite-test kernel. The reverse inclusion follows from the actual factorization through \(P'\), and the finite-test domination lemma extends equality to all test modules. This proves the criterion without interchanging an unrestricted colimit and product.

For the universally exact sequence at 21565, tensoring with the product gives an exact row, and the product of the individually exact rows is exact. If the middle comparison is injective, the first is injective by its inclusion into the middle row. If the first and third comparisons are injective and a middle element maps to zero, its image at the third top term is zero; lift it from the first top term, where injectivity of the first comparison makes the lift zero. These are precisely the two asserted ML permanence statements.

For the quotient result at 21591, lift an element of the third top term with zero comparison image to the second top term. Its comparison image comes from the first bottom term by exactness. Finite generation makes the first comparison surjective, so lift that preimage to the first top term and subtract its image from the chosen second-top lift. The difference has zero middle comparison, hence is zero by the ML hypothesis on \(M_2\). Its image at the third top term was the original element, so that element is zero. This uses the source's finite generation assumption exactly.

In a filtered system with universally injective transitions, each map from a stage to the colimit stays injective after every tensor test: an element mapping to zero vanishes at a later stage, and that transition is injective. Thus every product of the individual stage-to-colimit tensor maps is injective. Representing one tensor-product kernel element at a stage now proves the colimit lemma. Finite direct sums are handled by the universally exact split sequences; an arbitrary direct sum is the filtered union of its finite subsums with split transitions. Conversely, every summand inclusion is split after tensoring, so the pure-submodule result applies. These maps also justify the earlier free and projective ML examples.

For restriction along \(R\to S\) in 21663–21687, keep the source's actual composite
\[
M\otimes_R\prod Q_\alpha
\cong M\otimes_S(S\otimes_R\prod Q_\alpha)
\longrightarrow M\otimes_S\prod(S\otimes_RQ_\alpha)
\longrightarrow\prod(M\otimes_RQ_\alpha).
\]
The associativity maps send \(m\otimes q\) to \(m\otimes(1\otimes q)\), with inverse \(m\otimes(s\otimes q)\mapsto sm\otimes q\). The first displayed arrow preserves the ML injection for \(S\) because \(M\) is flat over \(S\); the second is the ML comparison for \(M\) over \(S\). Their composite on simple tensors is the original \(R\)-comparison, proving the stated restriction result.

## Coherent-module extensions and the retained image correction

Source 21700–21844; `OCC-12108` and `OCC-00456` retain `MC-STK-ERR-0451`. The second report's named proposition is inaccurate, but its line range identifies the correct step in `lemma-coherent`. The left term of
\[
0\longrightarrow\operatorname{im}\varphi\longrightarrow E'\longrightarrow E\longrightarrow0
\]
is the finite image, not the kernel from a different sequence. The existing operation supplies exactly that image.

Here are the finiteness arguments with the original modules. The image of the finite \(N\) is finite, hence finitely presented because it lies in coherent \(M\). Take a finite free surjection onto \(N\). The kernel of its composite onto \(\operatorname{im}\varphi\) is finite, since that target is finitely presented; its image surjects onto \(\ker\varphi\), proving the latter finite. For a finite submodule \(E\) of the cokernel, choose lifts to \(E'\) of finitely many generators of \(E\) and adjoin generators of \(\operatorname{im}\varphi\). Their span is all \(E'\). It is therefore finitely presented as a finite submodule of \(M\). Quotienting a finite presentation by a finite generated submodule adds finitely many lifted generator relations, so \(E\) is finitely presented. This proves the corrected cokernel argument and coherence of the image and cokernel.

The coherent kernel is a finite submodule of coherent \(N\). In an extension with coherent end terms, the middle term is finite by lifting generators. For its finite submodule \(N_2\), the image \(N_3\) is finitely presented in the third coherent module; the preceding kernel argument makes \(N_1\) finite, hence finitely presented in the first coherent module. The original extension of these two finite presentations presents \(N_2\) finitely. Explicitly, lift finitely many generators of \(N_3\) to \(N_2\), adjoin generators of \(N_1\), lift the finitely many relations of \(N_3\) into those of \(N_1\), and adjoin the relations of \(N_1\). Any relation reduces first to a relation in the quotient and then to one in \(N_1\), proving these finitely many relations suffice. This completes all the stated coherent-module implications.

The coherent-ring criterion follows with the author's original product maps. A finite ideal \(I\) is finitely presented over a coherent ring, so
\(I\otimes\prod Q_\alpha\to\prod(I\otimes Q_\alpha)\)
is the original comparison isomorphism. Its composite into \(\prod Q_\alpha\) is injective if each \(Q_\alpha\) is flat, giving flatness of the product by the ideal criterion. Conversely, if every \(R^A\) is flat, the map \(I\otimes R^A\to R^A\) is injective. Its image is \(I^A\), because finite generation makes the product comparison onto. Thus the comparison \(I\otimes R^A\to I^A\) is an isomorphism for every \(A\); the preceding finite-presentation criterion makes \(I\) finitely presented. The zero ideal and empty products cause no exception. The valuation-ring and Noetherian examples retain their original hypotheses; their finite ideals are respectively principal free ideals (or zero), and finite presented ideals by Noetherianity.

## The finite-free content criterion and products over the source ring

Source 21859–21993. `OCC-00457` inserts the second “if”; `OCC-00458` inserts “of”. A finite module is ML exactly when it is finitely presented, since the finite-generation comparison is onto, the ML comparison is injective, and the combined isomorphism is the finite-presentation criterion.

Reports `OCC-12109` and `OCC-00459` retain `MC-STK-ERR-0452`: there are **three** undefined occurrences of \(J\), at 21937 and twice at 21944, all already changed to \(I\) by its two operations. The smaller report's suggested count of two occurrences does not reduce this complete correction.

In the original flat ML criterion, let \(D=\operatorname{Hom}_R(M_i,R)\), and retain the finite free stages. Choose a basis \(e_1,\ldots,e_r\) of \(M_j\), and write the actual transition tensor as
\[
f_{ij}=\sum_{a=1}^r \lambda_a\otimes e_a\in D\otimes M_j.
\]
The coefficients \(\lambda_a\) are the images of the dual basis under \(\operatorname{Hom}(f_{ij},R)\). Thus \(Q_j=\sum_aR\lambda_a\). Because \(M_j\) is free, this tensor belongs to \(L\otimes M_j\) for a submodule \(L\subset D\) precisely when each \(\lambda_a\in L\). This proves the smallest-submodule assertion used in the source.

Let \(Q\) be the smallest submodule containing the canonical tensor \(f_i\) after tensoring by \(M\). Since \(M\) is flat, these tensor inclusions are actual injections. Each original \(Q_j\) contains \(Q\). A tensor representation of \(f_i\) in \(Q\otimes M\) is represented in \(Q\otimes M_k\) at some stage. Choose a common stage above \(i,k\); the image of this representative and the transition tensor from \(M_i\) have the same colimit image in \(D\otimes M\). At a further common stage they are equal. Hence the source's \(f_{ij}\) belongs to \(Q\otimes M_j\) there, so \(Q_j\subset Q\). This proves stabilization with the original maps and, by the earlier dual criterion, ML. The other direction follows from the minimal-submodule lemma.

For \(M=R^A\) over Noetherian \(R\), flatness follows from the coherent-ring criterion just checked. Every submodule \(F'\) of a finite free \(F\) is finitely presented. The product comparisons therefore identify the original inclusion \(F'\otimes R^A\to F\otimes R^A\) with \((F')^A\to F^A\). For the given tuple \((x_\alpha)\), its coordinate span \(F'=\sum_\alpha Rx_\alpha\subset F\) is the smallest such submodule and is finite by Noetherianity. `OCC-00460` repairs only the malformed apposition “submodule of F' of F”. For the power-series statement, the coefficient map from the original \(R[[t_1,\ldots,t_n]]\) to \(R^{\mathbb N^n}\) and the inverse formal coefficient sum are \(R\)-linear inverse maps. For finite positive \(n\), the set of exponent tuples is countable; every original monomial and its coefficient is retained.

## The non-ML examples with their original elements

Source 21995–22040. Reports `OCC-00461` and `OCC-00462` require only “generated by” and the relation symbol `\gg`. The mathematical assertions are correct, as follows.

For \(R=k[[x]]\), keep \(M=\prod_{n\geq1}R/(x^n)\) and the displayed element whose coordinate at \(n=2^m\), \(m\geq1\), is \(x^{2^{m-1}}\), and whose other coordinates are zero. This is exactly the displayed sequence starting \((0,x,0,x^2,\ldots)\). If the natural-number indexing also includes zero, that extra module \(R/(x^0)\) is zero and has no effect. Coordinatewise division of elements in the image of multiplication by \(x^l\) gives
\[
M/x^lM\cong\prod_{n\geq1}R/(x^{\min(n,l)}).
\]
Thus the annihilator of the original \(\xi\) is the intersection of the coordinate annihilators, namely
\[
\operatorname{Ann}_R(\xi\bmod x^lM)=(x^{b(l)}),
\quad b(l)=\max_{m\geq1}\max\{\min(2^m,l)-2^{m-1},0\}.
\]
Only finitely many terms are positive. For \(l=2^r\), \(r\geq1\), the maximum is \(2^{r-1}\): the term \(m=r\) attains it, earlier terms are smaller, and later terms vanish. This proves the exact annihilator claimed in the source.

For any finite \(R\)-module \(Q\) and its actual element \(\xi'\), let \(A=R\xi'\subset Q\). The earlier original Artin–Rees lemma, `lemma-Artin-Rees`, gives \(c\) such that
\[
A\cap x^lQ=x^{l-c}(A\cap x^cQ)\qquad(l\geq c).
\]
If \(\xi'\) is torsion with annihilator \((x^a)\), the right side is zero for \(l\geq c+a\), so its annihilator modulo \(x^lQ\) is exactly \((x^a)\). This includes \(\xi'=0\), with \(a=0\). Otherwise the map \(R\to A\), \(r\mapsto r\xi'\), is injective. Its inverse image of \(A\cap x^cQ\) is a principal ideal \((x^b)\), with \(0\leq b\leq c\), because it contains \(x^cR\). The displayed Artin–Rees equality then gives the annihilator \((x^{l-c+b})=(x^{l-a})\), where \(a=c-b\geq0\), for all \(l\geq c\). This retains the original submodule and every exponent; no replacement of \(Q\) by a presumed decomposition is used. Neither eventual form agrees with \((x^{2^{r-1}})\) for all large \(l=2^r\). Applying ML condition (1) to \(R\to M\), \(1\mapsto\xi\), would give a finitely presented, hence finite, \(Q\) with equality of all these tensor-test kernels for \(R/(x^l)\). The contradiction proves the example.

For the completion of \(D=\bigoplus_{n\geq1}R/(x^n)\), retain the exact completion \(\widehat D=\lim_l D/x^lD\). The coordinate maps identify it with the submodule of the above product consisting of sequences \((a_n)\) for which, for each \(l\), all but finitely many coordinates belong to \(x^lR/(x^n)\). Indeed a compatible finite-support residue family determines each coordinate once \(l\geq n\), and conversely such a sequence supplies finite-support residues at each \(l\); these maps are inverse. Moreover
\[
\widehat D\cap x^lM=x^l\widehat D.
\]
For the nontrivial inclusion, divide the original coordinate polynomials by \(x^l\), choosing zero for zero coordinates. If the original sequence is eventually divisible by \(x^{l+s}\), the resulting sequence is eventually divisible by \(x^s\), so it still lies in \(\widehat D\). The displayed equality makes \(\widehat D/x^l\widehat D\to M/x^lM\) injective. The original \(\xi\) lies in \(\widehat D\) because its nonzero valuations tend to infinity. Its annihilators modulo every \(x^l\) are therefore the same ones just computed, and the same finite-module contradiction applies.

For the last example, retain \(R=k[a,b]/(a^2,ab,b^2)\) and \(S=R[t]/(at-b)\). There is an exact comparison with pairs of polynomials:
\[
f(t)+a g(t)+b h(t)\longmapsto(f(t),g(t)+t h(t)),
\quad (f,g)\longmapsto f+a g\text{ in }S,
\]
where pair multiplication is \((f,g)(f',g')=(ff',fg'+gf')\). The first map kills \(at-b\), and its kernel before quotienting consists exactly of \((b-at)h\); thus these are inverse ring maps. Under them the original actions are \(a(f,g)=(0,f)\), \(b(f,g)=(0,tf)\).

Every \(R\)-linear endomorphism of the original \(S\), written using this comparison, has form
\[
(f,g)\longmapsto(hf,Hf+hg)
\]
for some polynomial \(h\in k[t]\) and some \(k\)-linear map \(H:k[t]\to k[t]\). To prove this, commuting with \(a\) forces the image of \((0,g)\) to be \((0,Fg)\), where \(F\) is the first component on \((g,0)\); commuting with \(b\) forces \(F(tf)=tF(f)\). Hence \(F\) is multiplication by \(h=F(1)\), while the second component \(H\) on \((f,0)\) is unrestricted. If the endomorphism is idempotent, then \(h^2=h\), so \(h=0\) or \(1\) in the domain \(k[t]\). The second component of the idempotence equation gives \(H=0\) in either case, in every characteristic. Only the zero and identity idempotents exist, proving indecomposability. The original elements \(t^n\) generate countably, while the quotient by \((a,b)\) is \(k[t]\), so the module is not finite.

The non-ML conclusion can be checked without relying on the later henselian splitting lemma. Let \(S_n=R\langle1,t,\ldots,t^n\rangle\subset S\). These are finite presented \(R\)-modules because \(R\) is finite dimensional over \(k\), hence Noetherian, and their union is \(S\). Their first polynomial coordinates have degree at most \(n\); their second coordinates have degree at most \(n+1\). For a proposed stabilization stage \(j\) at \(i=0\), set \(k=j+1\). A factor \(u:S_k\to S_j\) of the inclusion from \(S_0\) would satisfy \(u(1)=1\). Write \(F_r\) for the first coordinate of \(u(t^r)\). The original relations \(at^{r+1}=bt^r\) give \(F_{r+1}=tF_r\), so \(F_r=t^r\). At \(r=k\), this contradicts the degree bound \(j\) in \(S_j\). Thus condition (3) fails for every \(j\), proving non-ML directly while preserving the original example and its source attribution.

## Countable subsystem, parity and cofinal sequences

Source 22052–22179. The two article reports `OCC-12110`, `OCC-00463` retain `MC-STK-ERR-0453`, which already says “a countable set”. The two parity reports `OCC-12111`, `OCC-00464` retain `MC-STK-ERR-0454`. Its witness step acts on even stages and its directed-enlargement step on odd stages, exactly as in the explicit first two cycles.

A countable subset of a directed set can be enlarged to a countable directed subset by adjoining an upper bound for every pair, repeating countably many times, and taking the union. There are countably many pairs at each step. The alternating original construction therefore yields a countable directed \(I'\) containing the chosen generator stages and, for each of its stages \(i\), an index \(j\in I'\) whose map factors through every \(k\geq i\) in the original \(I\). The canonical colimit map is onto because its image contains every generator. If a represented element becomes zero in the full colimit, it vanishes at some such \(k\). The factor at \(j\) kills it already in the restricted system, proving injectivity. No cofinality of \(I'\) in the entire original \(I\) is asserted or needed.

Report `OCC-00465` correctly detects the reversed order, but changing the relation symbol alone leaves a boundary error: a finite directed set cannot contain a subset isomorphic to \(\mathbb N\). The proposed minimal replacement says to obtain **an increasing cofinal sequence indexed by \((\mathbb N,\leq)\)**. Repetitions are allowed, including a constant sequence at a greatest element. Given an enumeration of the countable directed set, repeat entries if needed and choose successive upper bounds. For the colimit comparison, send a representative at an original index \(i\) to its image at any sequence stage above \(i\). Different choices agree at a common later sequence stage. Any original equality is witnessed at an original upper stage and then at a sequence stage above it, so this map is well-defined and inverse to the canonical map from the sequential colimit. This proves the intended assertion for finite and infinite index sets.

The polynomial example at 22109–22114 is correct. Its ideal \((x_i)\) is not finite generated: a proposed finite list of polynomial generators uses only finitely many variables, and setting those variables to zero leaves another \(x_j\) nonzero. Hence the cyclic quotient is not finitely presented. Its sequential presentation by \(R/(x_1,\ldots,x_n)\) is still the exact colimit, because the union of the defining ideals is \((x_i)\). Sequential finite presentation alone therefore does not give the ML property.

In `lemma-ML-countable`, a prescribed \(y\in E_j\) lifts to the inverse limit of the stable-image system, not merely to an unspecified nonempty inverse limit. To verify the source's use of the earlier lemma, choose an increasing cofinal sequence starting above \(j\). Surjectivity of the stable-image transition gives a first lift of \(y\), and then successive lifts. Extend this sequence to the full compatible family using the exact receiving maps proved in group 510. It projects to \(y\). Its \(k\)-component is the original \(z_k:M\to M_k\) with \(z_k f_j=f_{jk}\). Hence \(\alpha=f_kz_k\) fixes \(\operatorname{im}f_j\), and therefore fixes \(f(P)\). Finite generation of \(P\) is used only to put its image in one stage; it need not supply a map \(P\to M_j\). This validates the source proof without an additional rewrite.

## Projectivity and the original countability boundary

Source 22192–22299. Restrict the Lazard finite free presentation of a flat countably generated ML module to the countable subsystem just proved. For any short exact sequence \(0\to N_1\to N_2\to N_3\to0\), finite freeness gives the source exact Hom sequence at every stage. The ML condition stabilizes the inverse system with target \(N_1\). The exact inverse-limit theorem then gives surjectivity onto \(\lim\operatorname{Hom}(M_i,N_3)\). The maps
\[
\operatorname{Hom}(M,N)\longrightarrow\lim_i\operatorname{Hom}(M_i,N),
\quad h\longmapsto(hf_i)_i
\]
have inverse defined on a colimit class by \([m_i]\mapsto h_i(m_i)\); compatibility proves independence and linearity. Thus \(\operatorname{Hom}(M,-)\) preserves this arbitrary short exact sequence, proving projectivity.

The example \(\mathbb Z[[x]]\) retains its essential countability boundary. For the original submodule \(N\) of coefficient sequences tending to zero \(p\)-adically, the map \((a_i)\mapsto\sum_i a_i p^i x^i\) from \(\mathbb Z^{\mathbb N}\) is injective, so \(N\) is uncountable. Reduction of coefficients maps \(N\) onto \(\bigoplus_{i\geq0}\mathbb F_p x^i\), since every reduced sequence has finite support and every finite-support sequence lifts to a polynomial. Its kernel is exactly \(pN\): division of a sequence divisible coordinatewise by \(p\) preserves the defining decay, using the original condition at exponent \(m+1\). Thus \(N/pN\) has countably infinite dimension. A free abelian group of countable rank is countable, while a free group of uncountable rank has uncountable-dimensional reduction modulo \(p\). Therefore \(N\) is not free.

The assertion that subgroups of free abelian groups are free has a proof compatible with the previously reviewed original filtration. Well-order the original basis of a free group \(F\), and intersect a subgroup \(H\) with the initial coordinate sums. Each successor quotient of the intersections injects into the corresponding \(\mathbb Z\) coordinate, so is an ideal \(d\mathbb Z\) or zero; it is free of rank at most one. Lift a generator to split the successor extension. At a limit the intersections commute with the coordinate union by finite support. The original direct-sum dévissage lemma now makes \(H\) a direct sum of those free quotients. A projective abelian group is a subgroup of a free group and is therefore free; its subgroups would also be free. The explicit \(N\) contradicts this for \(\mathbb Z[[x]]\).

The source projectivity characterization consequently keeps all three conditions. In a direct sum, flatness and ML pass to every summand; countably generated summands satisfying both are projective by the preceding proof. A direct sum of projectives is projective because, for any surjection, lift each summand's map separately and combine on finite-support elements. The converse is the already reviewed Kaplansky decomposition and permanence of flatness and ML under summands. The pure-submodule and power-series corollaries follow by the actual pure injection, the source flatness descent for its domain, and the checked tensor criterion.

`OCC-00466` inserts the article in “be a universally injective map”. `OCC-00467` is rejected: authority line 22289 already reads `let $M$ be an $R$-module`, and the current interval has that same reading. No operation is warranted by its inaccurate quotation.

## Source ascent, descent and the countable image construction

Source 22303–22460. Base change preserves flatness by the actual tensor associativity test on injections of \(S\)-modules, and it preserves the original splitting that witnesses projectivity. It commutes with direct sums and sends a countable list of generators to a countable list of tensor generators. The ML ascent proof agrees exactly with group 511's tensoring of the original factor maps. None of these arguments changes the source module into an unrelated \(S\)-module.

Reports `OCC-00468` and `OCC-00469` supply “to be” and lowercase “is”. In the faithfully flat ML proof, retain its pushout
\[
N=(M_j\oplus M)/\{(f_{ij}(x),-f_i(x)):x\in M_i\}.
\]
Tensoring this cokernel constructs the exact displayed pushout over \(S\). ML of \(M\otimes S\) gives \(j\) for which \(M_j\otimes S\to N\otimes S\) is universally injective. For any original test module \(T\), use the \(S\)-test \(T\otimes S\) and the canonical associativity maps. The resulting injection is the base change of \(M_j\otimes T\to N\otimes T\). Faithful flatness reflects this injection, proving universal injectivity over \(R\) and hence domination of \(f_i\) by \(f_{ij}\).

In fact the reflection step also holds for the pure maps of group 511: for any map \(u:X\to Y\), if \(u_S\) is injective and \(u(x)=0\), then \(x\otimes1=0\), and purity of \(X\to X\otimes S\) gives \(x=0\). Apply this to each of the original tensor-test maps just specified. This supplies a second exact proof of the already recorded pure ML descent, propagated through the source's actual pushout. The source faithfully flat hypothesis and its human attribution remain in the translated statement.

For countable generation, the source collects all original entries \(x_{ij}\) in finite tensor expressions of a countable generating family \(y_i\). Their span \(M'\) is countably generated and the image of \(M'\otimes S\to M\otimes S\) contains every \(y_i\), hence is onto. Right exactness gives \((M/M')\otimes S=0\), so faithful flatness makes \(M'=M\). The same finite-entry construction for a countably generated submodule \(Q\subset M\otimes S\) only asserts containment in the image of \(P\otimes S\); it never assumes that map injective. `OCC-00470` inserts “to” in this latter construction.

For the complete adapted-submodule lemma, let \(M\otimes S=\bigoplus_i Q_i\) be its original decomposition. The image of a countably generated \(N'_\ell\) is generated over \(S\) by a countable list, each with finite coordinate support. Thus the set \(I'_\ell\) of its nonzero coordinate projections is countable. The direct sum of those countably generated \(Q_i\) is countably generated, so the previous finite-entry construction gives \(P\) whose tensor image contains it. Set \(N'_{\ell+1}=N'_\ell+P\). Images into \(M\otimes S\) commute with this increasing union, by the finite expression of each tensor. Every such image is contained in the sum of its coordinate supports, and every \(Q_i\) in a stage support is contained in the next image. Hence the union image is exactly \(\bigoplus_{i\in\bigcup I'_\ell}Q_i\), as claimed. This proves the lemma for arbitrary ring maps while retaining its use of images. The next projectivity-descent theorem has not been adjudicated.

## Arbitrary intersections and base change of the smallest submodule

This is a separate consequence of `lemma-minimal-contains` and `lemma-flat-ML-criterion`, with complete original-map proofs. For a flat module \(M\), the ML property is equivalent to preservation of arbitrary intersections of submodules of every \(F\):
\[
\left(\bigcap_\alpha F_\alpha\right)\otimes_R M
=\bigcap_\alpha(F_\alpha\otimes_R M)
\quad\text{inside }F\otimes_RM.
\]
For the forward implication, the kernel of \(F\to\prod_\alpha F/F_\alpha\) is the displayed intersection. Flatness identifies the kernel after tensoring with that intersection tensored by \(M\). The ML product-comparison injection shows this is also the kernel of the map into \(\prod_\alpha((F/F_\alpha)\otimes M)\), whose kernel is exactly the right-hand intersection by flatness and right exactness at each coordinate. Empty families give \(F\) on both sides. Conversely, the asserted intersection identity supplies the smallest submodule for any tensor in a finite free \(F\), by intersecting all submodules that contain it after tensoring. This family is nonempty because it contains \(F\). The criterion proved above makes \(M\) ML. In either direction the smallest submodule is finite: write its tensor element as a finite sum using its own entries, take their span, and apply minimality.

There is also an exact arbitrary-base-change formula for this smallest submodule. Write \(C_R(x)\subset F\) for it, for the original \(x\in F\otimes_RM\). For any ring map \(R\to S\), let \(x_S\) be its image in \(F_S\otimes_S M_S\). Then
\[
C_S(x_S)=\operatorname{im}(C_R(x)\otimes_RS\longrightarrow F\otimes_RS).
\]
Here the image is essential: no injection of \(C_R(x)\otimes S\) is assumed.

To prove this with original coefficients, use a finite free Lazard presentation \(M=\operatorname{colim}M_i\). Represent \(x\) by \(x_i\in F\otimes M_i\). Choose \(j\geq i\) for which \(f_{ij}\) dominates \(f_i\). In an original basis \(e_1,\ldots,e_r\) of \(M_j\), write its image exactly as
\[
x_j=\sum_{a=1}^r y_a\otimes e_a,
\qquad C=\sum_{a=1}^r Ry_a\subset F.
\]
Its image gives \(x\in C\otimes M\). If \(x\in F'\otimes M\), its image in \((F/F')\otimes M\) is zero. Domination with this test module makes the image of \(x_j\) zero in \((F/F')\otimes M_j\). Freeness forces each original \(y_a\in F'\), so \(C\subset F'\). Thus \(C=C_R(x)\).

After arbitrary base change, both stages remain finite free. For every \(S\)-module \(T\), the tensor-test maps for these stages are exactly the original maps with the underlying \(R\)-module \(T\), by associativity. Hence the same domination holds over \(S\). Also \(M_S\) is flat and ML, by the established ascent statements. Repeat the preceding coefficient argument in \(F_S\), using the original coefficients \(y_a\otimes1\) and the base-changed basis. It gives \(C_S(x_S)=\sum_a S(y_a\otimes1)\), which is precisely the stated image. This includes zero ranks, zero tensors and nonflat ring maps. It strengthens the original smallest-submodule statement without silently replacing it in a translation.

## Pure descent of countable generation and the resulting projective cases

This is a separate propagation of groups 501 and 511 through the source results just checked. If \(R\to S\) is pure and \(M_S\) is countably generated, the original finite-entry construction gives countably generated \(M'\subset M\) with \((M/M')\otimes S=0\). Purity of the unit map of the **actual quotient** \(M/M'\) gives \(M/M'=0\). Thus countable generation descends along pure maps. More generally, the same proof descends generation by at most an infinite cardinal \(\kappa\): a union of \(\kappa\) finite sets has size at most \(\kappa\). This is not a claim of preservation of an exact finite number of generators.

If \(M_S\) is countably generated and projective, it is flat and ML over \(S\). Group 501's complete matrix-cokernel argument descends flatness to the original \(M\), and group 511, or the pushout reflection proof above, descends ML. Countable generation descends as just proved. The original countable-projectivity proof therefore makes \(M\) countably generated and projective. Conversely, countable generation and an actual projective splitting both ascend along every ring map, by their original tensor maps. Thus countably generated projectivity is equivalent before and after a pure ring map.

There is a second, explicitly bounded receiving case. Suppose the original \(R\)-module \(M\) is a direct sum of countably generated \(R\)-modules, and \(M_S\) is projective. The same two descents give flatness and ML over \(R\). With the given original decomposition, all three hypotheses of the source projectivity characterization hold, so \(M\) is projective. The reverse implication again ascends along any ring map. This argument retains that decomposition hypothesis; it does not claim descent of an arbitrary decomposition from \(S\) or unrestricted projectivity descent along every pure ring map. In particular, it does not try to apply the source pure-submodule theorem to \(M_S\) as an \(R\)-module, where flatness of \(S\) was not assumed.

## Propagation and reading limits

Groups 512–526 account for all nineteen reports, including four retained canonical units and one rejected quotation. The cofinal-sequence correction includes the finite-index boundary missed by the report's proposed symbol-only edit. Group 527 records intersection preservation and the exact image formula for base change of the smallest submodule, with zero source operations. Group 528 records pure descent of countable generation and the two bounded projectivity consequences, receiving groups 501 and 511 and the original projectivity criterion. The earlier pure ML result is also propagated through the source's actual pushout argument, giving an independent proof with the same conclusion. The original Noetherian product hypotheses and the uncountable-projectivity counterexample remain intact.

The new disk query `coherent Mittag-Leffler` returned two research PDF-routing hits: *Éléments de géométrie algébrique III, première partie* and *Basic Oka Theory in Several Complex Variables*. Both remain unread and unused here; no PDF fallback or new EGA coverage is claimed. The exact supplied original Stacks TeX provides the current primary treatment. Earlier topic snapshots and external-reading records remain historical evidence. The next theorem's statement is only lookahead, and broader combined-results synthesis remains after core completion.
