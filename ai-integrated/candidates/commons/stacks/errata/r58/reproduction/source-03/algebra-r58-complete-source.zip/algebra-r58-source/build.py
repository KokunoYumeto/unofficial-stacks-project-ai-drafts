"""Reproduce the Algebra chapter and complete editorial companion from bound sources."""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
EPOCH = '1790010000'
sha = lambda b: hashlib.sha256(b).hexdigest().upper()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()


def validated_inputs():
    raw = (HERE / 'PACKAGE_MANIFEST.json').read_bytes()
    manifest = json.loads(raw)
    for row in manifest['files']:
        path = (HERE / row['file']).resolve()
        if not path.is_relative_to(HERE) or not path.is_file():
            raise ValueError('Missing or escaping package input: ' + row['file'])
        data = path.read_bytes()
        if sha(data) != row['sha256'] or len(data) != row['bytes']:
            raise ValueError('Changed package input: ' + row['file'])
    return raw, manifest


def diagnostics(log):
    patterns = {
        'fatal': r'^!\s+(?!\[\])\S.*|^.*(?:LaTeX Error|Package .* Error|Undefined control sequence|Emergency stop|Fatal error|Missing .* inserted|invalid character).*',
        'missing_glyph': r'^.*Missing character:.*',
        'undefined_reference': r'^.*(?:Reference .* undefined|There were undefined references).*',
        'undefined_citation': r'^.*(?:Citation .* undefined|There were undefined citations).*',
        'duplicate': r'^.*(?:multiply defined|duplicate ignored|destination with the same identifier).*',
        'rerun': r'^.*(?:Rerun to get|Label\(s\) may have changed|rerunfilecheck.*Warning).*',
        'overfull': r'^Overfull \\[hv]box.*',
        'underfull': r'^Underfull \\[hv]box.*',
    }
    result = {key: re.findall(pattern, log, re.M) for key, pattern in patterns.items()}
    # TeX wraps warning words and labels across physical lines.
    warning_blocks = re.findall(r'LaTeX Warning:[\s\S]*?(?=\n\s*\n|\Z)', log)
    for key, word in [('undefined_reference', 'reference'), ('undefined_citation', 'citation')]:
        result[key] = [block for block in warning_blocks
                       if 'undefined' in block.replace('\n', '').lower()
                       and word in block.replace('\n', '').lower()]
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--validate-only', action='store_true')
    parser.add_argument('--diagnostic-pass', action='store_true',
                        help='One companion pass only; never a release or fixed-point claim.')
    parser.add_argument('--assembled', action='store_true',
                        help='Compile the companion with every mathematical input expanded.')
    args = parser.parse_args()
    raw, manifest = validated_inputs()
    if args.validate_only:
        print(json.dumps(dict(status='PASS_PACKAGE_INPUTS', files=len(manifest['files']),
                              package_manifest_sha256=sha(raw), engines_launched=False)))
        return
    if args.output is None:
        parser.error('--output is required for compilation')
    out = args.output.resolve()
    if out.exists() or out == HERE or HERE.is_relative_to(out):
        raise ValueError('Choose a fresh output directory outside the source package')
    engines = {name: shutil.which(name) for name in ['pdflatex', 'xelatex', 'bibtex']}
    if not all(engines.values()):
        raise RuntimeError('Required executables: pdflatex, xelatex and bibtex')
    from tex_mutex import TexSlot
    if os.name == 'nt':
        from tex_process_guard import run_captured
    out.mkdir(parents=True)
    (out / 'PACKAGE_MANIFEST.json').write_bytes(raw)
    env = dict(os.environ, SOURCE_DATE_EPOCH=EPOCH, FORCE_SOURCE_DATE='1', TZ='UTC')
    receipt = dict(schema='stacks-algebra-portable-build/v1',
                   created_at_utc=datetime.now(timezone.utc).isoformat(),
                   package_manifest_sha256=sha(raw), companion_manifest_sha256=manifest['companion_manifest_sha256'],
                   source_date_epoch=EPOCH, builds=[], captures=[],
                   diagnostic_pass=args.diagnostic_pass, assembled=args.assembled,
                   visual_inspection=False, admission=False, publication=False)
    slot = TexSlot(1000)

    def launch(command, folder, name):
        capture = out / (name + '-capture.json')
        if os.name == 'nt':
            done = run_captured(command, cwd=folder, env=env, timeout=900,
                                caller_holds_tex_mutex=slot.owned, receipt_path=capture)
            receipt['captures'].append(dict(file=capture.name, sha256=sha(capture.read_bytes())))
        else:
            done = subprocess.run(command, cwd=folder, env=env, timeout=900,
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (out / (name + '-output.log')).write_text(done.stdout, encoding='utf-8')
        if done.returncode:
            raise RuntimeError('Engine failed at ' + name + '; complete output preserved')
        return done.stdout

    def build(folder, group, stem, engine, source=None):
        previous = None
        for sweep in range(1, 9):
            command = [engines[engine], '-no-shell-escape', '-interaction=nonstopmode',
                       '-halt-on-error', '-file-line-error', '-recorder', '-synctex=1']
            if 'miktex' in engines[engine].lower():
                command.append('--disable-installer')
            if source:
                command.append('-jobname=' + stem)
            command.append(source or stem + '.tex')
            launch(command, folder, group + '-' + stem + '-tex-' + str(sweep))
            if args.diagnostic_pass:
                return dict(group=group, document=stem, status='DRAFT_ONE_PASS_NOT_QA',
                            pdf_sha256=sha((folder / (stem + '.pdf')).read_bytes()))
            aux = (folder / (stem + '.aux')).read_bytes()
            if sweep == 1 and b'\\bibdata' in aux:
                output = launch([engines['bibtex'], stem], folder, group + '-' + stem + '-bibtex')
                if re.search(r"Warning--I didn't find|I couldn't open|error message", output, re.I):
                    raise RuntimeError('Unresolved bibliography at ' + group + '/' + stem)
            vector = {ext: sha((folder / (stem + '.' + ext)).read_bytes())
                      for ext in ['pdf', 'aux', 'out', 'toc', 'bbl'] if (folder / (stem + '.' + ext)).exists()}
            if vector == previous:
                break
            previous = vector
        else:
            raise RuntimeError('No fixed point within eight sweeps: ' + group + '/' + stem)
        diag = diagnostics((folder / (stem + '.log')).read_text(encoding='utf-8', errors='replace'))
        failures = {k: v for k, v in diag.items() if k not in ['overfull', 'underfull'] and v}
        result = dict(group=group, document=stem, sweeps=sweep, identities=vector,
                      diagnostics=diag, input_sha256=sha((folder / (source or stem + '.tex')).read_bytes()))
        receipt['builds'].append(result)
        if failures:
            raise RuntimeError('Unresolved diagnostics at ' + group + '/' + stem + ': ' + ', '.join(failures))
        print(json.dumps(dict(group=group, document=stem, sweeps=sweep,
                              pdf_sha256=vector['pdf'], overfull=len(diag['overfull']))), flush=True)
        return result

    try:
        with slot:
            groups = ['diagnostic'] if args.diagnostic_pass else ['prior', 'a', 'b']
            for group in groups:
                folder = out / group
                folder.mkdir()
                for row in manifest['files']:
                    name = row['file']
                    target = folder / name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes((HERE / name).read_bytes())
                if group == 'prior':
                    # Use the same verified reference/navigation adapters for both editions.
                    for name in ['algebra.tex', 'stacks-project.cls', 'my.bib']:
                        (folder / name).write_bytes((HERE / 'prior' / name).read_bytes())
                    build(folder, group, 'algebra', 'pdflatex')
                elif args.diagnostic_pass:
                    result = build(folder, group, 'algebra-editorial', 'xelatex',
                                   'algebra-editorial-assembled.tex' if args.assembled else None)
                    receipt['builds'].append(result)
                else:
                    build(folder, group, 'algebra', 'pdflatex')
                    build(folder, group, 'algebra-editorial', 'xelatex',
                          'algebra-editorial-assembled.tex' if args.assembled else None)
            if args.diagnostic_pass:
                receipt['status'] = 'DRAFT_ONE_PASS_NOT_QA'
            else:
                for stem in ['algebra', 'algebra-editorial']:
                    a = next(r for r in receipt['builds'] if r['group'] == 'a' and r['document'] == stem)
                    b = next(r for r in receipt['builds'] if r['group'] == 'b' and r['document'] == stem)
                    if a['identities'] != b['identities'] or a['diagnostics'] != b['diagnostics']:
                        raise RuntimeError('Fresh builds differ: ' + stem)
                receipt['status'] = 'PASS_FIXED_POINT_REPRODUCTION_VISUAL_PENDING'
    except Exception as error:
        receipt['error'] = str(error)
        receipt['status'] = ('NO_ENGINE_SLOT_UNAVAILABLE'
                             if 'not acquired' in str(error) and not receipt['captures'] else 'BUILD_ERROR')
    finally:
        receipt['mutex'] = getattr(slot, 'receipt', {})
        (out / 'BUILD_RECEIPT.json').write_bytes(dump(receipt))
    print(json.dumps(dict(status=receipt['status'], output=str(out),
                          builds=len(receipt['builds']), error=receipt.get('error'))))
    if receipt['status'] == 'BUILD_ERROR':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
