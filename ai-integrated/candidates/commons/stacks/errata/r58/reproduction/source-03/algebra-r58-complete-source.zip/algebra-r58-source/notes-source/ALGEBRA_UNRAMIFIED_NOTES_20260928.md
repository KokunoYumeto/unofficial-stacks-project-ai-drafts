# Unramified ring maps and the exact diagonal idempotent

## Source and scope

Source: Stacks Project authors, algebra.tex at commit
a04446e57ec1fbc252a871afcec7752fb2807b14, SHA256
FA8BB92E58A4F78A2BD01B3B6A4A87DE0A0D279F5DD90641B574DD5FBFFFA4F3.
The full 41377–41711 interval and twelve received reports are read here;
41712–41723 is read but unadjudicated. Dependency reading is bounded to
539–567, 2427–2458, 3921–3953, 38608–38652, 32653–32686,
27420–27450 and 39393–39419. These bounded excerpts are not claims that
all the associated proofs have been newly read. The already reviewed
formal, smooth, étale and local-integral notes retain their prior evidence.
Four indexed hits for “unramified diagonal” remain unread and unused.
The source's Henselian citation and EGA terminology are retained; no new
reading of those publications or novelty claim is made.

The source calls finite type plus \(\Omega_{S/R}=0\) unramified, and
finite presentation plus the same condition G-unramified. Keep these
definitions exactly. Neither a translation nor this review silently
changes them to a later preferred convention. The fuller arguments
and diagonal consequences below are separate editorial material.

## Source statements and the two reference repairs

Formal unramifiedness is equivalent to \(\Omega_{S/R}=0\), as proved
in the preceding section, so 41404–41421 follows with exactly the two
different finiteness hypotheses. For the thirteen assertions at
41423–41547, base change uses the differential base-change isomorphism
and the stated base-change finiteness lemma. Composition instead uses
\[
T\otimes_S\Omega_{S/R}\longrightarrow\Omega_{T/R}
\longrightarrow\Omega_{T/S}\longrightarrow0
\]
and lemma-compose-finite-type, which proves both composition finiteness
statements at 539–563. The source reference at 41477 to the
base-change finiteness lemma is replaced by this actual composition
lemma; the maps and claim remain the same.

For a principal localization, every relative derivation kills \(R\)
and kills \(f^{-1}\), since \(d(f^{-1})=-f^{-2}df=0\); the
presentation \(R[X]/(fX-1)\) is finite. For \(R/H\) every relative
derivation is zero, because it kills the surjective image of \(R\).
The quotient is finite type and is finitely presented when \(H\) is
finitely generated. Étale maps supply finite presentation and zero
differentials as already proved.

For finite-type \(R\to S\), write \(S\) using finitely many generators
\(x_1,\ldots,x_n\). Their differentials generate \(\Omega_{S/R}\).
If its localization at \(\mathfrak q\) vanishes, choose one denominator
outside \(\mathfrak q\) annihilating each \(dx_i\), and multiply those
finitely many denominators to get \(g\notin\mathfrak q\) annihilating
the module after localization. Then \(\Omega_{S_g/R}=0\).
Finite type, and finite presentation when assumed, survive this principal
localization. The residue-field criterion is equivalent by Nakayama
for this finite localized module. Differential base change identifies
the fibre criterion with the same residue vector space, so all four
local tests in items (6)–(9) agree. Their finite-type hypothesis is
used to pass from residue vanishing to an actual open neighbourhood.

For a finite principal cover \(D(g_j)\), vanishing of the localized
differentials implies global vanishing; local finite type and local
finite presentation glue by lemma-cover. This proves item (10).
In item (11), neither global finiteness hypothesis has yet been given.
Its hypothesis instead gives, at every prime, a principal open where
the corresponding finite-type or finite-presentation condition and
vanishing differentials hold. Quasi-compactness extracts finitely many
such opens. They cover the spectrum, so the \(g_j\) generate the unit
ideal, and item (10) applies. The reference to (6) and (7) at 41519
must therefore be replaced by the definition and (10). This is the
actual argument, not an added global finiteness assumption.
For \(S=0\), the map is already finitely presented as \(R/(1)\) and
has zero differentials, so the empty-spectrum case is also covered.

For item (12), retain the exact finite presentation
\(S=R[x_1,\ldots,x_n]/(g_1,\ldots,g_m)\).
The vanishing of the differential cokernel gives all the actual identities
\[
dx_i=\sum_j h_{ij}\,dg_j+\sum_{j,k}a_{ijk}g_j\,dx_k
\]
in the original free differential module over \(R[x_1,\ldots,x_n]\).
Adjoin to \(\mathbf Z\) every coefficient of \(g_j,h_{ij},a_{ijk}\)
to get the subring \(R_0\subset R\). These finitely many identities
hold over \(R_0\) itself, because its inclusion in \(R\) is injective.
Thus the displayed \(S_0\) is finitely presented with
\(\Omega_{S_0/R_0}=0\), and its original base change is \(S\).
For item (13), use the source's full identities
\[
dx_i=\sum_j h_{ij}\,dg_{ij}+\sum_k g'_{ik}\,dx_k,\qquad
g_{ij},g'_{ik}\in I.
\]
Only finitely many of these polynomials occur. Keeping every coefficient
gives the source \(S_0=R_0[x_1,\ldots,x_n]/(g_{ij},g'_{ik})\).
It has zero relative differentials and its base change surjects onto
the original \(S=R[x_1,\ldots,x_n]/I\).
In fact the constructed \(S_0/R_0\) is already G-unramified, since its
displayed relation list is finite. This is an explicit consequence of
the existing proof, not an error in the source's weaker conclusion.

For 41567–41641, replace \(S\) only by the stated neighbourhood and
then its actual fibre \(F=S\otimes_R\kappa(\mathfrak p)\).
It is finite type over the field and has zero differentials. The field
smoothness criterion at 38609 applies because zero is at most its
nonnegative local component dimension; hence it is smooth with zero
differentials, and is étale. The already proved field characterization
identifies \(F\) with a finite product of finite separable fields.
Its local ring at the original fibre prime is
\[
F_{\bar{\mathfrak q}}=S_{\mathfrak q}/\mathfrak pS_{\mathfrak q}
=\kappa(\mathfrak q).
\]
This gives both equality of maximal ideals and the exact finite
separable residue extension. The fibre point is isolated, giving
quasi-finiteness. Conversely, the two residue conditions give that
same fibre local ring as a finite separable field; its differential
module is zero, and the finite-type fibre test proves unramifiedness.
No claim of flatness follows from these residue conditions alone.

The equivalence étale \(\Leftrightarrow\) flat plus G-unramified
retains finite presentation. The previous étale criterion applies to
the flat local maps with the just proved zero-dimensional separable
fibres. The reverse implication uses the already proved flatness of
étale maps.

Finally let the source map
\(\varphi:k[x_1,\ldots,x_n]\to A,\ x_i\mapsto a_i\), be finite type.
This is finite presentation because its polynomial base is Noetherian.
If \(da_1,\ldots,da_n\) generate \(\Omega_{A/k}\), the exact
differential sequence gives
\(\Omega_{A/k[x_1,\ldots,x_n]}=0\), so \(\varphi\) is unramified.
At a maximal ideal \(\mathfrak m\) of \(A\), its residue field is
finite algebraic over \(k\). The image of the polynomial base in it
is generated by finitely many algebraic elements; it is a finite
dimensional domain over \(k\), hence a field. Thus
\(\varphi^{-1}(\mathfrak m)\) is maximal, and its regular local
polynomial ring has dimension \(n\).
Under condition (a), the target local dimension is also \(n\);
condition (b) bounds the differential residue dimension by \(n\).
The field smoothness criterion makes \(A_{\mathfrak m}\) regular,
hence Cohen–Macaulay. Its fibre over the polynomial local base is
the finite separable residue field just proved, of dimension zero.
All hypotheses of miracle flatness at 32654 are now met, including
the exact dimension equality \(n=n+0\). This proves flatness at
every maximal ideal and hence globally. Conversely, étaleness gives
condition (b), flatness and the same zero-dimensional fibres.
The original local dimension formula gives condition (a).
For \(A=0\), the criteria are vacuous and the empty étale algebra
still satisfies the statement; no maximal-ideal argument is needed.

## The diagonal, its determinant and equality of maps

For any map \(R\to S\), put
\[
D=S\otimes_RS,\qquad \mu:D\to S,\quad a\otimes b\mapsto ab,\qquad
J=\ker\mu.
\]
The exact diagonal-differential comparison gives \(J/J^2=\Omega_{S/R}\).
When \(R\to S\) is finite type, \(J\) is generated by the actual
elements \(u_i=x_i\otimes1-1\otimes x_i\), where the \(x_i\) are
the chosen algebra generators. Indeed the quotient by these elements
identifies the two structural maps from \(S\); the map
\(S\to D/(u_i)\), \(s\mapsto s\otimes1\), is then inverse to \(\mu\).
Thus an unramified map has a finitely generated ideal \(J=J^2\).

More generally only finite generation of \(J\), not finite type of
\(S\), is needed in the following exact construction. Choose actual
generators \(u_1,\ldots,u_m\) of \(J=J^2\), and write
\[
u_i=\sum_{j=1}^m a_{ij}u_j,\quad a_{ij}\in J,\qquad
e=\det(I_m-(a_{ij}))
=\sum_{\pi\in\mathfrak S_m}\operatorname{sgn}(\pi)
\prod_{i=1}^m(\delta_{i,\pi(i)}-a_{i,\pi(i)}).
\tag{UR-1}
\]
The adjugate applied to \((I_m-(a_{ij}))(u_i)_i=0\) gives
\(eJ=0\). Every entry of the coefficient matrix lies in \(J\),
so \(e-1\in J\), and \(e(e-1)=0\). Hence
\[
e^2=e,\quad \mu(e)=1,\quad J=(1-e)D.
\tag{UR-2}
\]
For the last equality, \(1-e\in J\) and each \(j\in J\) is
\((1-e)j\). For \(m=0\), the empty determinant is \(1\), \(J=0\),
and the same formulas hold. These formulas also hold for the zero ring.

The maps
\[
S\longrightarrow eD,\quad s\longmapsto(s\otimes1)e,\qquad
eD\longrightarrow S,\quad z\longmapsto\mu(z)
\tag{UR-3}
\]
are inverse: for \(d\in D\), \(d-\mu(d)\otimes1\in J\), annihilated
by \(e\). The first map is \(D\)-linear when \(S\) is a \(D\)-module
through \(\mu\), since that same difference is killed by \(e\).
Consequently \(S\) is a direct summand of the rank-one free
\(D\)-module \(D=eD\oplus(1-e)D\), hence is a finite projective
\(D\)-module, and \(D_e\to S\) is the exact original multiplication
quotient. Its inverse sends \(s\) to \((s\otimes1)/1\).
In \(D_e\) the idempotent \(e\) is \(1\), so this agrees with (UR-3).
This is a statement about the diagonal algebra \(D\), not projectivity
or finiteness of \(S\) as an \(R\)-module.

The following three conditions on an arbitrary \(R\to S\) are equivalent:
formal unramifiedness with \(J\) finitely generated; existence of \(e\)
as in (UR-2); and projectivity of \(S\) as a \(D\)-module.
The first implication is (UR-1), and the second gives projectivity
by (UR-3). For the converse, a \(D\)-linear section \(\sigma\) of
\(\mu\) exists. Put \(e=\sigma(1)\). Then \(\mu(e)=1\) and \(Je=0\).
The same argument gives \(e^2=e\) and \(J=(1-e)D\), hence \(J\)
is finitely generated and \(J/J^2=0\). Thus \(\Omega_{S/R}=0\).
The idempotent is unique: if \(e'\) has the same properties, then
\(e-e'\in J\), so \(e(e-e')=e'(e-e')=0\), giving
\(e=ee'=e'\). The determinant construction is therefore independent
of the selected generators and expressions, even though it preserves
them as its explicit formula.

Every base change \(R\to R_1\) carries this idempotent to the diagonal
idempotent for \(S_1=R_1\otimes_RS\), under
\(R_1\otimes_RD\cong S_1\otimes_{R_1}S_1\).
The multiplication map has the \(R\)-linear section \(s\mapsto s\otimes1\),
so its kernel sequence remains exact after this base change. Alternatively
the decomposition in (UR-2) itself tensors to the asserted kernel
decomposition. Neither argument assumes \(R_1\) flat.

For two \(R\)-algebra maps \(f,g:S\to B\), let
\(h:D\to B,\ h(a\otimes b)=f(a)g(b)\), and put \(d=h(e)\).
The ideal generated by all differences \(f(s)-g(s)\) is exactly
\[
\mathfrak a=h(J)B=(1-d)B,\qquad d^2=d.
\tag{UR-4}
\]
Here \(J\) is generated by the differences in the two tensor factors,
and (UR-2) gives the equality. Thus
\(B/\mathfrak a\cong B_d\), and on this factor the two original maps
are equal. It is the largest factor on which they agree: for every
\(B\)-algebra \(B'\), equality of their composites is equivalent to
the image of \(1-d\) being zero, equivalently the image of \(d\)
being \(1\), equivalently factorization through \(B_d\).
The equality subscheme is exactly the open and closed subset \(D(d)\)
with this ring structure, including all nilpotents. Formula (UR-4)
commutes with arbitrary further base change of \(B\).
If \(\operatorname{Spec}(B)\) is nonempty and connected, then
\(d\in\{0,1\}\); therefore equality at even one residue-field point
forces \(d=1\) and \(f=g\) on the whole ring. Connectedness here
does not require reducedness.

The finite diagonal condition has a real boundary. Take the already
used tower \(K_n=\mathbf Q(2^{1/2^n})\) with compatible positive
roots and \(L=\bigcup_nK_n\). The Eisenstein degrees \(2^n\) make
this an infinite algebraic extension, and characteristic zero makes
it separable. Every \(\alpha\in L\) satisfies a separable minimal
polynomial \(F\); differentiating gives \(F'(\alpha)d\alpha=0\).
The nonzero field element \(F'(\alpha)\) is a unit, hence
\(\Omega_{L/\mathbf Q}=0\). But its diagonal admits no idempotent
as above. If \(e=\sum a_i\otimes b_i\) existed, choose \(n\) with
all \(b_i\in K_n\) and choose \(\alpha\in L\setminus K_n\).
The equality \((\alpha\otimes1)e=(1\otimes\alpha)e\) would put
the first side in \(L\otimes_{\mathbf Q}K_n\) and the second in
\(L\otimes_{\mathbf Q}\alpha K_n\). These subspaces have zero
intersection, because \(K_n\cap\alpha K_n=0\), and tensoring
vector spaces over \(\mathbf Q\) preserves that direct sum.
Both sides would be zero. Multiplication by \(1\otimes\alpha\)
is invertible, forcing \(e=0\), contrary to \(\mu(e)=1\).
Hence this formally unramified map has a diagonal ideal which is
not finitely generated and no projective diagonal module.
It is not a counterexample to the source's finite-type theorem.

## Report decisions and propagation

Seven groups cover the twelve reports exactly once and give seven
operations: paired article reports 12212/942; paired finite-presentation
wording 12213/943; composition reference 944; local-to-global reference
945; paired maximal-ideal sentence 946/12214; paired plural verb
12215/947; and paired modal spelling 948/12216.
The two reference repairs are mathematical corrections of the stated
proof dependencies. The other changes preserve the exact hypotheses
and conclusions as copyedits. No prior canonical correction lies in
this source interval.

One zero-operation editorial group proves the exact determinant
idempotent, the weaker finite-diagonal hypothesis and its converse via
projectivity, arbitrary base change, the full equality factor for two
maps, and the infinite separable-extension boundary.
It receives the formal-unramified criterion from the preceding review
and the exact field tower from group 1181, retaining every diagonal
map and determinant coefficient. The stronger G-unramified choice
already supplied by the finite-coefficient construction is recorded
as existing proof content. All fuller arguments and consequences stay
editorial; they do not replace the original exposition. Broader
synthesis and its paper follow core completion.
